import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BrainCircuit, Video, BarChart, Mic, Users, ArrowRight } from 'lucide-react';

const Hero = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Video,
      title: 'Video Practice',
      description: 'Record yourself answering interview questions'
    },
    {
      icon: BrainCircuit,
      title: 'AI Analysis',
      description: 'Get insights on speech patterns and body language'
    },
    {
      icon: Mic,
      title: 'Voice Feedback',
      description: 'Receive personalized audio recommendations'
    },
    {
      icon: BarChart,
      title: 'Progress Tracking',
      description: 'Monitor your improvement over time'
    }
  ];

  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-secondary-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="text-center">
          {/* Main heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Master Your
            <span className="text-primary-600 dark:text-primary-400"> Interview Skills </span>
            with AI
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            Practice interviews with AI-powered feedback on your speech patterns, body language, 
            and answer structure. Get personalized coaching to land your dream job.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={() => navigate('/signup')}
              className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
            >
              <span>Start Practicing Free</span>
              <ArrowRight className="h-5 w-5" />
            </button>
            <button
              onClick={() => navigate('/demo')}
              className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-900 dark:text-white border-2 border-gray-200 dark:border-gray-600 px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200 transform hover:scale-105"
            >
              Watch Demo
            </button>
          </div>

          {/* Features grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-20">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="bg-primary-100 dark:bg-primary-900/30 w-12 h-12 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <feature.icon className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>

          {/* Social proof */}
          <div className="mt-20 text-center">
            <p className="text-gray-500 dark:text-gray-400 text-sm mb-8">
              Trusted by professionals at leading companies
            </p>
            <div className="flex items-center justify-center space-x-8 opacity-60">
              <Users className="h-8 w-8 text-gray-400" />
              <span className="text-gray-400 font-semibold">Google</span>
              <Users className="h-8 w-8 text-gray-400" />
              <span className="text-gray-400 font-semibold">Microsoft</span>
              <Users className="h-8 w-8 text-gray-400" />
              <span className="text-gray-400 font-semibold">Amazon</span>
              <Users className="h-8 w-8 text-gray-400" />
              <span className="text-gray-400 font-semibold">Meta</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;