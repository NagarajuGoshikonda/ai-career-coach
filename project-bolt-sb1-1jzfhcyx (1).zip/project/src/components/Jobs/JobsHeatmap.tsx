import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import CalendarHeatmap from 'react-calendar-heatmap';
import { TrendingUp, MapPin, DollarSign, Users, Briefcase, Clock } from 'lucide-react';
import GlassPanel from '../UI/GlassPanel';
import { jobDataEngine } from '../../services/jobDataEngine';
import { TrendingSkill, JobListing } from '../../types/jobs';

interface JobsHeatmapProps {
  className?: string;
}

const JobsHeatmap = ({ className = '' }: JobsHeatmapProps) => {
  const [trendingSkills, setTrendingSkills] = useState<TrendingSkill[]>([]);
  const [recentJobs, setRecentJobs] = useState<JobListing[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | '90d'>('30d');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [selectedTimeframe]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [skills, jobs] = await Promise.all([
        jobDataEngine.getTrendingSkills(selectedTimeframe),
        jobDataEngine.searchJobs({ limit: 20 })
      ]);
      
      setTrendingSkills(skills);
      setRecentJobs(jobs);
    } catch (error) {
      console.error('Failed to load job data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateHeatmapData = () => {
    const data = [];
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 365);

    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      data.push({
        date: new Date(d).toISOString().split('T')[0],
        count: Math.floor(Math.random() * 50) + 1
      });
    }
    return data;
  };

  const getSkillGrowthColor = (growth: string) => {
    switch (growth) {
      case 'rising': return 'text-green-400';
      case 'stable': return 'text-yellow-400';
      case 'declining': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSkillGrowthIcon = (growth: string) => {
    switch (growth) {
      case 'rising': return '📈';
      case 'stable': return '➡️';
      case 'declining': return '📉';
      default: return '❓';
    }
  };

  if (loading) {
    return (
      <GlassPanel className={`p-6 ${className}`}>
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-white/20 rounded w-1/3"></div>
          <div className="h-32 bg-white/20 rounded"></div>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-4 bg-white/20 rounded"></div>
            ))}
          </div>
        </div>
      </GlassPanel>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header with timeframe selector */}
      <GlassPanel className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Job Market Heatmap</h2>
            <p className="text-gray-300">Real-time insights into trending roles and skills</p>
          </div>
          
          <div className="flex items-center space-x-2">
            {(['7d', '30d', '90d'] as const).map((timeframe) => (
              <motion.button
                key={timeframe}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedTimeframe(timeframe)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedTimeframe === timeframe
                    ? 'bg-blue-600 text-white'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20'
                }`}
              >
                {timeframe === '7d' ? '7 Days' : timeframe === '30d' ? '30 Days' : '90 Days'}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Job posting activity heatmap */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Clock className="h-5 w-5 mr-2" />
            Job Posting Activity (Last 12 Months)
          </h3>
          <div className="bg-black/20 p-4 rounded-lg">
            <CalendarHeatmap
              startDate={new Date(Date.now() - 365 * 24 * 60 * 60 * 1000)}
              endDate={new Date()}
              values={generateHeatmapData()}
              classForValue={(value) => {
                if (!value || value.count === 0) return 'color-empty';
                if (value.count < 10) return 'color-scale-1';
                if (value.count < 20) return 'color-scale-2';
                if (value.count < 30) return 'color-scale-3';
                return 'color-scale-4';
              }}
              tooltipDataAttrs={(value: any) => ({
                'data-tip': value.date ? `${value.count} jobs posted on ${value.date}` : 'No data'
              })}
            />
          </div>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/5 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Briefcase className="h-4 w-4 text-blue-400" />
              <span className="text-sm text-gray-300">New Jobs Today</span>
            </div>
            <div className="text-2xl font-bold text-white">247</div>
            <div className="text-sm text-green-400">+12% vs yesterday</div>
          </div>
          
          <div className="bg-white/5 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Users className="h-4 w-4 text-purple-400" />
              <span className="text-sm text-gray-300">Active Recruiters</span>
            </div>
            <div className="text-2xl font-bold text-white">1,234</div>
            <div className="text-sm text-blue-400">+5% this week</div>
          </div>
          
          <div className="bg-white/5 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <DollarSign className="h-4 w-4 text-green-400" />
              <span className="text-sm text-gray-300">Avg Salary</span>
            </div>
            <div className="text-2xl font-bold text-white">$95k</div>
            <div className="text-sm text-green-400">+8% this month</div>
          </div>
          
          <div className="bg-white/5 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <MapPin className="h-4 w-4 text-orange-400" />
              <span className="text-sm text-gray-300">Remote Jobs</span>
            </div>
            <div className="text-2xl font-bold text-white">68%</div>
            <div className="text-sm text-orange-400">+15% this year</div>
          </div>
        </div>
      </GlassPanel>

      {/* Trending Skills */}
      <GlassPanel className="p-6">
        <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2" />
          Trending Skills & Technologies
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {trendingSkills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-white/5 p-4 rounded-lg border border-white/10 hover:border-white/20 transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{getSkillGrowthIcon(skill.growth)}</span>
                  <h4 className="font-semibold text-white">{skill.name}</h4>
                </div>
                <span className={`text-sm font-medium ${getSkillGrowthColor(skill.growth)}`}>
                  +{skill.demand}%
                </span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Avg Salary:</span>
                  <span className="text-white">${skill.averageSalary.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Open Positions:</span>
                  <span className="text-white">{skill.jobCount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Category:</span>
                  <span className="text-blue-400">{skill.category}</span>
                </div>
              </div>
              
              {/* Demand bar */}
              <div className="mt-3">
                <div className="flex justify-between text-xs text-gray-400 mb-1">
                  <span>Demand Level</span>
                  <span>{skill.demand}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(skill.demand, 100)}%` }}
                    transition={{ delay: index * 0.1 + 0.5, duration: 0.8 }}
                    className={`h-2 rounded-full ${
                      skill.growth === 'rising' ? 'bg-green-500' :
                      skill.growth === 'stable' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassPanel>

      {/* Recent Job Postings */}
      <GlassPanel className="p-6">
        <h3 className="text-xl font-semibold text-white mb-6">Latest Job Postings</h3>
        
        <div className="space-y-4">
          {recentJobs.slice(0, 5).map((job, index) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 p-4 rounded-lg border border-white/10 hover:border-white/20 transition-all"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    {job.companyLogo && (
                      <img 
                        src={job.companyLogo} 
                        alt={job.company}
                        className="w-8 h-8 rounded object-cover"
                      />
                    )}
                    <div>
                      <h4 className="font-semibold text-white">{job.title}</h4>
                      <p className="text-sm text-gray-400">{job.company}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-300">
                    <span className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {job.location}
                    </span>
                    {job.salary.min && (
                      <span className="flex items-center">
                        <DollarSign className="h-3 w-3 mr-1" />
                        ${job.salary.min.toLocaleString()} - ${job.salary.max?.toLocaleString()}
                      </span>
                    )}
                    <span className="text-xs text-gray-500">
                      {new Date(job.postedDate).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 mt-2">
                    {job.remote && (
                      <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                        Remote
                      </span>
                    )}
                    {job.trending && (
                      <span className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs rounded-full">
                        🔥 Trending
                      </span>
                    )}
                    {job.verified && (
                      <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full">
                        ✓ Verified
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="text-right">
                  {job.matchScore && (
                    <div className="text-sm">
                      <span className="text-gray-400">Match: </span>
                      <span className={`font-semibold ${
                        job.matchScore >= 80 ? 'text-green-400' :
                        job.matchScore >= 60 ? 'text-yellow-400' : 'text-red-400'
                      }`}>
                        {job.matchScore}%
                      </span>
                    </div>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors"
                  >
                    View Details
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
};

export default JobsHeatmap;