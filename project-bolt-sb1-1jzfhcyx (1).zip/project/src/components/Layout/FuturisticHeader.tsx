import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { useAppStore } from '../../stores/appStore';
import { 
  BrainCircuit, 
  Moon, 
  Sun, 
  User, 
  LogOut, 
  Settings,
  MessageCircle,
  Zap,
  Menu,
  X,
  Briefcase,
  TrendingUp,
  Target,
  BarChart3
} from 'lucide-react';
import GlassPanel from '../UI/GlassPanel';
import Avatar3D from '../UI/Avatar3D';
import OmnichannelChatbot from '../Chat/OmnichannelChatbot';

const FuturisticHeader = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useAppStore();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: BarChart3 },
    { path: '/jobs', label: 'Jobs Portal', icon: Briefcase },
    { path: '/practice', label: 'Practice', icon: Target },
    { path: '/progress', label: 'Progress', icon: TrendingUp }
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="relative z-40"
      >
        <GlassPanel className="m-4 px-6 py-4" blur="xl">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <motion.div 
              className="flex items-center space-x-3 cursor-pointer group" 
              onClick={() => navigate('/')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="relative">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur-sm opacity-50"
                />
                <BrainCircuit className="relative h-8 w-8 text-blue-400 group-hover:text-blue-300 transition-colors" />
              </div>
              <div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  AI Career Nexus
                </span>
                <div className="text-xs text-gray-400">v3.0 Neural Edition</div>
              </div>
            </motion.div>

            {/* Navigation */}
            {user && (
              <nav className="hidden md:flex space-x-2">
                {navItems.map((item) => (
                  <motion.button
                    key={item.path}
                    onClick={() => navigate(item.path)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 flex items-center space-x-2 ${
                      location.pathname === item.path
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-400/30'
                        : 'text-gray-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </motion.button>
                ))}
              </nav>
            )}

            {/* Right side controls */}
            <div className="flex items-center space-x-3">
              {/* AI Chat Button */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsChatOpen(true)}
                className="relative p-3 text-gray-300 hover:text-white transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full"
                />
              </motion.button>

              {/* Theme toggle */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={toggleTheme}
                className="p-3 text-gray-300 hover:text-white transition-colors"
              >
                <AnimatePresence mode="wait">
                  {theme === 'light' ? (
                    <motion.div
                      key="moon"
                      initial={{ rotate: -90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: 90, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Moon className="h-5 w-5" />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="sun"
                      initial={{ rotate: -90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: 90, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Sun className="h-5 w-5" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.button>

              {user ? (
                <div className="relative">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center space-x-3 p-2 text-gray-300 hover:text-white transition-colors"
                  >
                    <Avatar3D size="sm" />
                    <div className="hidden sm:block text-left">
                      <div className="text-sm font-medium text-white">{user.fullName}</div>
                      <div className="text-xs text-gray-400 flex items-center">
                        <Zap className="h-3 w-3 mr-1" />
                        Pro Member
                      </div>
                    </div>
                  </motion.button>
                  
                  {/* Profile dropdown */}
                  <AnimatePresence>
                    {isProfileOpen && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: -10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: -10 }}
                        className="absolute right-0 mt-2 w-64 z-50"
                      >
                        <GlassPanel className="p-4">
                          <div className="space-y-3">
                            <div className="flex items-center space-x-3 pb-3 border-b border-white/10">
                              <Avatar3D size="sm" />
                              <div>
                                <div className="text-sm font-medium text-white">{user.fullName}</div>
                                <div className="text-xs text-gray-400">{user.email}</div>
                              </div>
                            </div>
                            
                            <motion.button
                              whileHover={{ x: 5 }}
                              onClick={() => navigate('/settings')}
                              className="flex items-center w-full px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-all"
                            >
                              <Settings className="h-4 w-4 mr-3" />
                              Settings
                            </motion.button>
                            
                            <motion.button
                              whileHover={{ x: 5 }}
                              onClick={handleLogout}
                              className="flex items-center w-full px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-all"
                            >
                              <LogOut className="h-4 w-4 mr-3" />
                              Sign out
                            </motion.button>
                          </div>
                        </GlassPanel>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigate('/login')}
                    className="text-gray-300 hover:text-white text-sm font-medium transition-colors"
                  >
                    Sign in
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigate('/signup')}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-lg"
                  >
                    Get Started
                  </motion.button>
                </div>
              )}

              {/* Mobile menu button */}
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden p-2 text-gray-300 hover:text-white transition-colors"
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </motion.button>
            </div>
          </div>

          {/* Mobile menu */}
          <AnimatePresence>
            {isMenuOpen && user && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden mt-4 pt-4 border-t border-white/10"
              >
                <div className="space-y-2">
                  {navItems.map((item) => (
                    <motion.button
                      key={item.path}
                      onClick={() => {
                        navigate(item.path);
                        setIsMenuOpen(false);
                      }}
                      whileHover={{ x: 5 }}
                      className={`flex items-center w-full px-3 py-2 text-sm font-medium rounded-lg transition-all ${
                        location.pathname === item.path
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'text-gray-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <item.icon className="h-4 w-4 mr-3" />
                      {item.label}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </GlassPanel>
      </motion.header>

      {/* Omniscient Chatbot */}
      <AnimatePresence>
        {isChatOpen && (
          <OmnichannelChatbot 
            isOpen={isChatOpen} 
            onClose={() => setIsChatOpen(false)} 
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default FuturisticHeader;