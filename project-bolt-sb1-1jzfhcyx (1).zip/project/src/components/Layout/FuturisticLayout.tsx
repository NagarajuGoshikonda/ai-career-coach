import React from 'react';
import FuturisticHeader from './FuturisticHeader';
import AnimatedBackground from '../UI/AnimatedBackground';

interface FuturisticLayoutProps {
  children: React.ReactNode;
}

const FuturisticLayout = ({ children }: FuturisticLayoutProps) => {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <AnimatedBackground />
      <FuturisticHeader />
      <main className="relative z-10">
        {children}
      </main>
    </div>
  );
};

export default FuturisticLayout;