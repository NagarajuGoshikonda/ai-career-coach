import React, { useRef, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import { useVideoRecorder } from '../../hooks/useVideoRecorder';
import { analyzeVideoWithTavus, getMockTavusAnalysis } from '../../services/tavus';
import { generateVoiceFeedback } from '../../services/elevenlabs';
import { uploadVideoToSupabase } from '../../services/supabase';
import { 
  Play, 
  Square, 
  Pause, 
  Video, 
  Mic, 
  MicOff, 
  VideoOff, 
  AlertCircle, 
  CheckCircle,
  Loader2,
  Volume2,
  RotateCcw,
  TestTube
} from 'lucide-react';
import toast from 'react-hot-toast';

interface EnhancedVideoRecorderProps {
  onAnalysisComplete?: (analysis: any, audioUrl?: string) => void;
  question: string;
  questionId: string;
}

interface AnalysisState {
  isAnalyzing: boolean;
  isGeneratingAudio: boolean;
  analysis: any | null;
  audioUrl: string | null;
  error: string | null;
}

const EnhancedVideoRecorder = ({ 
  onAnalysisComplete, 
  question, 
  questionId 
}: EnhancedVideoRecorderProps) => {
  const webcamRef = useRef<Webcam>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [analysisState, setAnalysisState] = useState<AnalysisState>({
    isAnalyzing: false,
    isGeneratingAudio: false,
    analysis: null,
    audioUrl: null,
    error: null
  });

  const {
    isRecording,
    isPaused,
    duration,
    error,
    isInitializing,
    hasPermission,
    stream,
    initializeCamera,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    cleanup,
    testRecording
  } = useVideoRecorder({
    onRecordingComplete: handleRecordingComplete,
    onError: (error) => toast.error(error)
  });

  useEffect(() => {
    return cleanup;
  }, [cleanup]);

  useEffect(() => {
    if (webcamRef.current && stream) {
      // The webcam component handles the stream automatically
    }
  }, [stream]);

  async function handleRecordingComplete(blob: Blob) {
    setAnalysisState(prev => ({ ...prev, isAnalyzing: true, error: null }));
    
    try {
      // Upload video to Supabase
      const fileName = `interview-${questionId}-${Date.now()}.mp4`;
      const videoUrl = await uploadVideoToSupabase(blob, fileName);
      
      toast.success('Video uploaded successfully');
      
      // Analyze with Tavus AI
      let analysis;
      if (import.meta.env.DEV || !import.meta.env.VITE_TAVUS_API_KEY) {
        // Use mock data in development or when API key is not available
        analysis = getMockTavusAnalysis();
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 2000));
      } else {
        analysis = await analyzeVideoWithTavus(videoUrl);
      }
      
      setAnalysisState(prev => ({ 
        ...prev, 
        analysis, 
        isAnalyzing: false, 
        isGeneratingAudio: true 
      }));
      
      toast.success('Video analysis completed');
      
      // Generate voice feedback
      let audioUrl = null;
      try {
        audioUrl = await generateVoiceFeedback(analysis);
        toast.success('Voice feedback generated');
      } catch (audioError) {
        console.error('Voice feedback error:', audioError);
        toast.error('Voice feedback generation failed, but analysis is complete');
      }
      
      setAnalysisState(prev => ({ 
        ...prev, 
        audioUrl, 
        isGeneratingAudio: false 
      }));
      
      onAnalysisComplete?.(analysis, audioUrl || undefined);
      
    } catch (error: any) {
      console.error('Analysis error:', error);
      const errorMessage = error.message || 'Analysis failed';
      setAnalysisState(prev => ({ 
        ...prev, 
        error: errorMessage, 
        isAnalyzing: false, 
        isGeneratingAudio: false 
      }));
      toast.error(errorMessage);
    }
  }

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const toggleAudio = () => {
    if (stream) {
      const audioTracks = stream.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !isAudioEnabled;
      });
      setIsAudioEnabled(!isAudioEnabled);
      toast(isAudioEnabled ? 'Microphone muted' : 'Microphone enabled');
    }
  };

  const toggleVideo = () => {
    if (stream) {
      const videoTracks = stream.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !isVideoEnabled;
      });
      setIsVideoEnabled(!isVideoEnabled);
      toast(isVideoEnabled ? 'Camera disabled' : 'Camera enabled');
    }
  };

  const playAudioFeedback = () => {
    if (analysisState.audioUrl && audioRef.current) {
      audioRef.current.src = analysisState.audioUrl;
      audioRef.current.play().catch(error => {
        console.error('Audio playback error:', error);
        toast.error('Failed to play audio feedback');
      });
    }
  };

  const retryAnalysis = () => {
    setAnalysisState({
      isAnalyzing: false,
      isGeneratingAudio: false,
      analysis: null,
      audioUrl: null,
      error: null
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      {/* Question header */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
          Practice Question
        </h3>
        <p className="text-gray-600 dark:text-gray-300">{question}</p>
      </div>

      {/* Video area */}
      <div className="relative bg-gray-900 aspect-video">
        {!hasPermission && !isInitializing ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white p-8">
              <Video className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">Camera Access Required</h3>
              <p className="text-gray-300 mb-4">
                Please allow camera and microphone access to start recording
              </p>
              <button
                onClick={initializeCamera}
                className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Enable Camera
              </button>
            </div>
          </div>
        ) : isInitializing ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
              <p>Initializing camera...</p>
            </div>
          </div>
        ) : error ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white p-8">
              <AlertCircle className="h-16 w-16 mx-auto mb-4 text-error-500" />
              <h3 className="text-lg font-semibold mb-2">Camera Error</h3>
              <p className="text-gray-300 mb-4">{error}</p>
              <div className="space-x-3">
                <button
                  onClick={initializeCamera}
                  className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  <RotateCcw className="h-4 w-4 inline mr-2" />
                  Retry
                </button>
                <button
                  onClick={testRecording}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  <TestTube className="h-4 w-4 inline mr-2" />
                  Test
                </button>
              </div>
            </div>
          </div>
        ) : (
          <Webcam
            ref={webcamRef}
            audio={true}
            video={true}
            mirrored={true}
            className="w-full h-full object-cover"
            videoConstraints={{
              width: 1280,
              height: 720,
              facingMode: 'user'
            }}
          />
        )}
        
        {/* Recording indicator */}
        {isRecording && !isPaused && (
          <div className="absolute top-4 left-4 bg-error-600 text-white px-3 py-1 rounded-full flex items-center space-x-2 animate-pulse">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">REC {formatDuration(duration)}</span>
          </div>
        )}

        {/* Paused indicator */}
        {isPaused && (
          <div className="absolute top-4 left-4 bg-warning-600 text-white px-3 py-1 rounded-full flex items-center space-x-2">
            <Pause className="w-3 h-3" />
            <span className="text-sm font-medium">PAUSED {formatDuration(duration)}</span>
          </div>
        )}

        {/* Analysis overlay */}
        {(analysisState.isAnalyzing || analysisState.isGeneratingAudio) && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="text-center text-white">
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {analysisState.isAnalyzing ? 'Analyzing Video...' : 'Generating Voice Feedback...'}
              </h3>
              <p className="text-gray-300">
                {analysisState.isAnalyzing 
                  ? 'AI is analyzing your speech patterns and body language' 
                  : 'Creating personalized audio feedback'
                }
              </p>
            </div>
          </div>
        )}

        {/* Controls overlay */}
        {hasPermission && !error && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-4">
            {/* Audio toggle */}
            <button
              onClick={toggleAudio}
              className={`p-3 rounded-full transition-colors ${
                isAudioEnabled 
                  ? 'bg-gray-800/60 text-white hover:bg-gray-700/60' 
                  : 'bg-error-600 text-white hover:bg-error-700'
              }`}
            >
              {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
            </button>

            {/* Record/Stop button */}
            {!isRecording ? (
              <button
                onClick={startRecording}
                disabled={analysisState.isAnalyzing || analysisState.isGeneratingAudio}
                className="bg-error-600 hover:bg-error-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-4 rounded-full transition-colors shadow-lg"
              >
                <Play className="h-6 w-6" />
              </button>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={isPaused ? resumeRecording : pauseRecording}
                  className="bg-warning-600 hover:bg-warning-700 text-white p-3 rounded-full transition-colors"
                >
                  {isPaused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
                </button>
                <button
                  onClick={stopRecording}
                  className="bg-gray-600 hover:bg-gray-700 text-white p-3 rounded-full transition-colors"
                >
                  <Square className="h-5 w-5" />
                </button>
              </div>
            )}

            {/* Video toggle */}
            <button
              onClick={toggleVideo}
              className={`p-3 rounded-full transition-colors ${
                isVideoEnabled 
                  ? 'bg-gray-800/60 text-white hover:bg-gray-700/60' 
                  : 'bg-error-600 text-white hover:bg-error-700'
              }`}
            >
              {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
            </button>
          </div>
        )}
      </div>

      {/* Analysis Results */}
      {analysisState.analysis && (
        <div className="p-6 bg-gray-50 dark:bg-gray-700/50">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
              Analysis Results
            </h4>
            {analysisState.audioUrl && (
              <button
                onClick={playAudioFeedback}
                className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2"
              >
                <Volume2 className="h-4 w-4" />
                <span>Play Feedback</span>
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                {analysisState.analysis.overall_score}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Overall Score</div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-2xl font-bold text-warning-600 dark:text-warning-400">
                {analysisState.analysis.filler_words}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Filler Words</div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-2xl font-bold text-success-600 dark:text-success-400">
                {analysisState.analysis.eye_contact_percentage}%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Eye Contact</div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-2xl font-bold text-secondary-600 dark:text-secondary-400">
                {analysisState.analysis.confidence_score}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Confidence</div>
            </div>
          </div>

          {analysisState.analysis.recommendations && (
            <div>
              <h5 className="font-medium text-gray-900 dark:text-white mb-2">Recommendations:</h5>
              <ul className="space-y-1">
                {analysisState.analysis.recommendations.map((rec: string, index: number) => (
                  <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                    <CheckCircle className="h-4 w-4 text-success-500 mr-2 mt-0.5 flex-shrink-0" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Error state */}
      {analysisState.error && (
        <div className="p-6 bg-error-50 dark:bg-error-900/20 border-t border-error-200 dark:border-error-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-error-600 dark:text-error-400" />
              <p className="text-error-600 dark:text-error-400 text-sm">{analysisState.error}</p>
            </div>
            <button
              onClick={retryAnalysis}
              className="bg-error-600 hover:bg-error-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="p-6 bg-gray-50 dark:bg-gray-700/50">
        <div className="flex items-start space-x-3">
          <div className="bg-primary-100 dark:bg-primary-900/30 p-2 rounded-lg">
            <Video className="h-4 w-4 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
              Recording Tips
            </h4>
            <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
              <li>• Ensure good lighting and clear audio</li>
              <li>• Look directly at the camera for eye contact</li>
              <li>• Take your time and speak clearly</li>
              <li>• Use the STAR method if applicable</li>
              <li>• Keep responses between 1-3 minutes</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Hidden audio element for feedback playback */}
      <audio ref={audioRef} className="hidden" />
    </div>
  );
};

export default EnhancedVideoRecorder;