import React from 'react';
import { Question } from '../../types';
import { Play, BookOpen, Lightbulb } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  onStartPractice: (question: Question) => void;
}

const QuestionCard = ({ question, onStartPractice }: QuestionCardProps) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-success-100 text-success-800 dark:bg-success-900/30 dark:text-success-400';
      case 'intermediate': return 'bg-warning-100 text-warning-800 dark:bg-warning-900/30 dark:text-warning-400';
      case 'advanced': return 'bg-error-100 text-error-800 dark:bg-error-900/30 dark:text-error-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'behavioral': return 'bg-primary-100 text-primary-800 dark:bg-primary-900/30 dark:text-primary-400';
      case 'technical': return 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-400';
      case 'leadership': return 'bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-400';
      case 'situational': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-3">
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(question.category)}`}>
              {question.category}
            </span>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getDifficultyColor(question.difficulty)}`}>
              {question.difficulty}
            </span>
            {question.starMethod && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                STAR
              </span>
            )}
          </div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
            {question.text}
          </h3>
        </div>
      </div>

      {/* Tips section */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-2">
          <Lightbulb className="h-4 w-4 text-warning-500" />
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Tips</span>
        </div>
        <ul className="space-y-1">
          {question.tips.slice(0, 2).map((tip, index) => (
            <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
              <span className="text-primary-500 mr-2">•</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-between">
        <button className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white flex items-center space-x-1">
          <BookOpen className="h-4 w-4" />
          <span>View all tips</span>
        </button>
        <button
          onClick={() => onStartPractice(question)}
          className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2"
        >
          <Play className="h-4 w-4" />
          <span>Start Practice</span>
        </button>
      </div>
    </div>
  );
};

export default QuestionCard;