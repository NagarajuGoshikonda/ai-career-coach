import React, { useRef, useEffect, useState } from 'react';
import { useMediaRecorder } from '../../hooks/useMediaRecorder';
import { Play, Square, Pause, Video, Mic, MicOff, VideoOff } from 'lucide-react';

interface VideoRecorderProps {
  onRecordingComplete: (blob: Blob) => void;
  question: string;
}

const VideoRecorder = ({ onRecordingComplete, question }: VideoRecorderProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);

  const {
    isRecording,
    isPaused,
    duration,
    error,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    stream
  } = useMediaRecorder({
    onStop: onRecordingComplete
  });

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const toggleAudio = () => {
    if (stream) {
      const audioTracks = stream.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !isAudioEnabled;
      });
      setIsAudioEnabled(!isAudioEnabled);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      const videoTracks = stream.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !isVideoEnabled;
      });
      setIsVideoEnabled(!isVideoEnabled);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      {/* Question header */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
          Practice Question
        </h3>
        <p className="text-gray-600 dark:text-gray-300">{question}</p>
      </div>

      {/* Video area */}
      <div className="relative bg-gray-900 aspect-video">
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="w-full h-full object-cover"
        />
        
        {/* Recording indicator */}
        {isRecording && !isPaused && (
          <div className="absolute top-4 left-4 bg-error-600 text-white px-3 py-1 rounded-full flex items-center space-x-2 animate-pulse">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <span className="text-sm font-medium">REC {formatDuration(duration)}</span>
          </div>
        )}

        {/* Paused indicator */}
        {isPaused && (
          <div className="absolute top-4 left-4 bg-warning-600 text-white px-3 py-1 rounded-full flex items-center space-x-2">
            <Pause className="w-3 h-3" />
            <span className="text-sm font-medium">PAUSED {formatDuration(duration)}</span>
          </div>
        )}

        {/* Controls overlay */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-4">
          {/* Audio toggle */}
          <button
            onClick={toggleAudio}
            className={`p-3 rounded-full transition-colors ${
              isAudioEnabled 
                ? 'bg-gray-800/60 text-white hover:bg-gray-700/60' 
                : 'bg-error-600 text-white hover:bg-error-700'
            }`}
          >
            {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </button>

          {/* Record/Stop button */}
          {!isRecording ? (
            <button
              onClick={startRecording}
              className="bg-error-600 hover:bg-error-700 text-white p-4 rounded-full transition-colors shadow-lg"
            >
              <Play className="h-6 w-6" />
            </button>
          ) : (
            <div className="flex items-center space-x-2">
              <button
                onClick={isPaused ? resumeRecording : pauseRecording}
                className="bg-warning-600 hover:bg-warning-700 text-white p-3 rounded-full transition-colors"
              >
                {isPaused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
              </button>
              <button
                onClick={stopRecording}
                className="bg-gray-600 hover:bg-gray-700 text-white p-3 rounded-full transition-colors"
              >
                <Square className="h-5 w-5" />
              </button>
            </div>
          )}

          {/* Video toggle */}
          <button
            onClick={toggleVideo}
            className={`p-3 rounded-full transition-colors ${
              isVideoEnabled 
                ? 'bg-gray-800/60 text-white hover:bg-gray-700/60' 
                : 'bg-error-600 text-white hover:bg-error-700'
            }`}
          >
            {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="p-4 bg-error-50 dark:bg-error-900/20 border-t border-error-200 dark:border-error-800">
          <p className="text-error-600 dark:text-error-400 text-sm">{error}</p>
        </div>
      )}

      {/* Instructions */}
      <div className="p-6 bg-gray-50 dark:bg-gray-700/50">
        <div className="flex items-start space-x-3">
          <div className="bg-primary-100 dark:bg-primary-900/30 p-2 rounded-lg">
            <Video className="h-4 w-4 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
              Recording Tips
            </h4>
            <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
              <li>• Ensure good lighting and clear audio</li>
              <li>• Look directly at the camera for eye contact</li>
              <li>• Take your time and speak clearly</li>
              <li>• Use the STAR method if applicable</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoRecorder;