import React from 'react';
import { motion } from 'framer-motion';

interface GlassPanelProps {
  children: React.ReactNode;
  className?: string;
  blur?: 'sm' | 'md' | 'lg' | 'xl';
  opacity?: number;
  animate?: boolean;
}

const GlassPanel = ({ 
  children, 
  className = '', 
  blur = 'md',
  opacity = 0.1,
  animate = true
}: GlassPanelProps) => {
  const blurClasses = {
    sm: 'backdrop-blur-sm',
    md: 'backdrop-blur-md',
    lg: 'backdrop-blur-lg',
    xl: 'backdrop-blur-xl'
  };

  const Component = animate ? motion.div : 'div';
  const animationProps = animate ? {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  } : {};

  return (
    <Component
      {...animationProps}
      className={`
        relative overflow-hidden rounded-2xl border border-white/20 
        ${blurClasses[blur]} 
        bg-white/10 dark:bg-black/10
        shadow-xl shadow-black/5 dark:shadow-white/5
        ${className}
      `}
      style={{
        background: `linear-gradient(135deg, 
          rgba(255, 255, 255, ${opacity}) 0%, 
          rgba(255, 255, 255, ${opacity * 0.5}) 100%
        )`
      }}
    >
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </Component>
  );
};

export default GlassPanel;