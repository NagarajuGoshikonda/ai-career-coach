import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  Paperclip,
  Search,
  Brain,
  Globe,
  FileText,
  Sparkles,
  X
} from 'lucide-react';
import GlassPanel from '../UI/GlassPanel';
import Avatar3D from '../UI/Avatar3D';
import { useAppStore } from '../../stores/appStore';
import toast from 'react-hot-toast';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type: 'text' | 'voice' | 'file';
  source?: 'knowledge_base' | 'google' | 'chatgpt' | 'deepseek';
  suggestions?: string[];
}

interface SmartChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const SmartChatbot = ({ isOpen, onClose }: SmartChatbotProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hi! I'm your AI career coach. I can help you with interview preparation, career advice, and answer questions using the latest information. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
      type: 'text',
      suggestions: [
        "How do I answer 'Tell me about yourself'?",
        "What are common interview mistakes?",
        "Help me practice behavioral questions",
        "What's trending in my industry?"
      ]
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { voiceEnabled } = useAppStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (content: string, type: 'text' | 'voice' = 'text') => {
    if (!content.trim() && !selectedFile) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: content || `Uploaded: ${selectedFile?.name}`,
      sender: 'user',
      timestamp: new Date(),
      type: selectedFile ? 'file' : type
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setSelectedFile(null);
    setIsTyping(true);

    try {
      // Simulate AI processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const response = await generateAIResponse(content, selectedFile);
      
      setMessages(prev => [...prev, response]);
      
      // Speak response if voice is enabled
      if (voiceEnabled && response.content) {
        speakText(response.content);
      }
    } catch (error) {
      toast.error('Failed to get response');
    } finally {
      setIsTyping(false);
    }
  };

  const generateAIResponse = async (query: string, file?: File | null): Promise<Message> => {
    // Simulate different AI sources based on query content
    let source: Message['source'] = 'knowledge_base';
    let content = '';
    let suggestions: string[] = [];

    if (query.toLowerCase().includes('trend') || query.toLowerCase().includes('latest')) {
      source = 'google';
      content = "Based on the latest industry trends from Google search, here are the current developments in your field...";
      suggestions = ["Tell me more about remote work trends", "What skills are in demand?"];
    } else if (query.toLowerCase().includes('technical') || query.toLowerCase().includes('code')) {
      source = 'deepseek';
      content = "Using DeepSeek's technical knowledge base, here's what you need to know...";
      suggestions = ["Explain system design concepts", "Help with coding interview prep"];
    } else if (query.toLowerCase().includes('advice') || query.toLowerCase().includes('strategy')) {
      source = 'chatgpt';
      content = "Drawing from ChatGPT's extensive training, here's my strategic advice...";
      suggestions = ["Create a career development plan", "Help me negotiate salary"];
    } else {
      content = "Based on our knowledge base, here's what I can tell you about interview preparation...";
      suggestions = ["Practice more questions", "Review my progress", "Get feedback on my answers"];
    }

    // Handle file uploads
    if (file) {
      if (file.type === 'application/pdf') {
        content = `I've analyzed your PDF document "${file.name}". Here are the key insights and how they relate to your interview preparation...`;
      } else if (file.type.startsWith('image/')) {
        content = `I've examined your image "${file.name}". This could be useful for portfolio discussions or visual presentation tips...`;
      }
    }

    return {
      id: Date.now().toString(),
      content,
      sender: 'bot',
      timestamp: new Date(),
      type: 'text',
      source,
      suggestions
    };
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      toast.error('Speech recognition not supported');
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      toast.success('Listening...');
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
      toast.error('Speech recognition failed');
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const speakText = (text: string) => {
    if (!voiceEnabled) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);

    speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast.error('File too large. Please select a file under 10MB.');
        return;
      }
      setSelectedFile(file);
      toast.success(`File "${file.name}" selected`);
    }
  };

  const getSourceIcon = (source?: Message['source']) => {
    switch (source) {
      case 'google': return <Globe className="h-3 w-3" />;
      case 'chatgpt': return <Brain className="h-3 w-3" />;
      case 'deepseek': return <Sparkles className="h-3 w-3" />;
      default: return <FileText className="h-3 w-3" />;
    }
  };

  const getSourceColor = (source?: Message['source']) => {
    switch (source) {
      case 'google': return 'text-blue-400';
      case 'chatgpt': return 'text-green-400';
      case 'deepseek': return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-4 z-50 flex items-center justify-center"
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      
      <GlassPanel className="relative w-full max-w-4xl h-full max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <Avatar3D size="sm" />
            <div>
              <h3 className="text-lg font-semibold text-white">AI Career Coach</h3>
              <p className="text-sm text-gray-300">Smart assistant with multi-source knowledge</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={isSpeaking ? stopSpeaking : () => {}}
              className={`p-2 rounded-lg transition-colors ${
                isSpeaking ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'
              }`}
            >
              {isSpeaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[70%] ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                <GlassPanel 
                  className={`p-4 ${
                    message.sender === 'user' 
                      ? 'bg-blue-500/20 border-blue-400/30' 
                      : 'bg-gray-500/20 border-gray-400/30'
                  }`}
                >
                  {message.sender === 'bot' && message.source && (
                    <div className={`flex items-center space-x-1 mb-2 text-xs ${getSourceColor(message.source)}`}>
                      {getSourceIcon(message.source)}
                      <span className="capitalize">{message.source.replace('_', ' ')}</span>
                    </div>
                  )}
                  
                  <p className="text-white text-sm leading-relaxed">{message.content}</p>
                  
                  {message.suggestions && (
                    <div className="mt-3 space-y-2">
                      <p className="text-xs text-gray-400">Suggested follow-ups:</p>
                      <div className="flex flex-wrap gap-2">
                        {message.suggestions.map((suggestion, index) => (
                          <button
                            key={index}
                            onClick={() => handleSendMessage(suggestion)}
                            className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </GlassPanel>
                
                <p className="text-xs text-gray-400 mt-1 px-2">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
              
              {message.sender === 'bot' && (
                <div className="order-1 mr-3">
                  <Avatar3D size="sm" />
                </div>
              )}
            </motion.div>
          ))}
          
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="flex items-center space-x-3">
                <Avatar3D size="sm" />
                <GlassPanel className="p-4 bg-gray-500/20">
                  <div className="flex space-x-1">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                  </div>
                </GlassPanel>
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 border-t border-white/10">
          {selectedFile && (
            <div className="mb-3 p-3 bg-blue-500/20 rounded-lg flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 text-blue-400" />
                <span className="text-sm text-white">{selectedFile.name}</span>
              </div>
              <button
                onClick={() => setSelectedFile(null)}
                className="text-gray-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
          
          <div className="flex items-center space-x-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx,.txt,image/*"
              className="hidden"
            />
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-gray-400 hover:text-white transition-colors"
            >
              <Paperclip className="h-5 w-5" />
            </button>
            
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
                placeholder="Ask me anything about interviews, careers, or industry trends..."
                className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <button
              onClick={isListening ? () => {} : startListening}
              className={`p-3 rounded-lg transition-colors ${
                isListening 
                  ? 'bg-red-500/20 text-red-400 animate-pulse' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSendMessage(inputValue)}
              disabled={!inputValue.trim() && !selectedFile}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-lg transition-colors"
            >
              <Send className="h-5 w-5" />
            </motion.button>
          </div>
        </div>
      </GlassPanel>
    </motion.div>
  );
};

export default SmartChatbot;