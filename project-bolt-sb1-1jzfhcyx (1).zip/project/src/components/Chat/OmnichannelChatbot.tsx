import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  Paperclip,
  Search,
  Brain,
  Globe,
  FileText,
  Sparkles,
  X,
  ThumbsUp,
  ThumbsDown,
  ExternalLink,
  Shield,
  Users,
  Zap,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import GlassPanel from '../UI/GlassPanel';
import Avatar3D from '../UI/Avatar3D';
import { useAppStore } from '../../stores/appStore';
import { omniscientChatbot } from '../../services/omniscientChatbot';
import toast from 'react-hot-toast';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type: 'text' | 'voice' | 'file';
  source?: 'chatgpt' | 'deepseek' | 'google' | 'human' | 'knowledge_base';
  confidence?: number;
  citations?: Citation[];
  verified?: boolean;
  rating?: number;
  suggestions?: string[];
}

interface Citation {
  title: string;
  url: string;
  snippet: string;
  source: string;
}

interface OmnichannelChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const OmnichannelChatbot = ({ isOpen, onClose }: OmnichannelChatbotProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hi! I'm your omniscient AI career assistant. I can help you with interview prep, career advice, salary insights, and market trends. I combine multiple AI models and real-time data to give you the most accurate and up-to-date information. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
      type: 'text',
      source: 'knowledge_base',
      confidence: 1.0,
      verified: true,
      suggestions: [
        "What are the trending skills in tech right now?",
        "Help me prepare for a software engineer interview",
        "What's the average salary for my role?",
        "Show me recent job market insights"
      ]
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [verificationMode, setVerificationMode] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { voiceEnabled } = useAppStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (content: string, requireVerification = false) => {
    if (!content.trim() && !selectedFile) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: content || `Uploaded: ${selectedFile?.name}`,
      sender: 'user',
      timestamp: new Date(),
      type: selectedFile ? 'file' : 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setSelectedFile(null);
    setIsTyping(true);

    try {
      const response = await omniscientChatbot.processQuery(content, {
        requireVerification: requireVerification || verificationMode,
        conversationHistory: messages
      });
      
      const botMessage: Message = {
        ...response,
        suggestions: generateSuggestions(content, response.source)
      };
      
      setMessages(prev => [...prev, botMessage]);
      
      // Speak response if voice is enabled
      if (voiceEnabled && response.content) {
        speakText(response.content);
      }
    } catch (error) {
      console.error('Chat error:', error);
      toast.error('Failed to get response');
    } finally {
      setIsTyping(false);
    }
  };

  const handleRateMessage = async (messageId: string, rating: number) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, rating } : msg
    ));
    
    await omniscientChatbot.rateResponse(messageId, rating);
    
    if (rating >= 4) {
      toast.success('Thanks for the feedback!');
    } else {
      toast('We\'ll improve our responses based on your feedback');
    }
  };

  const handleVerifyWithGoogle = async (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (!message) return;

    setIsTyping(true);
    try {
      const verifiedResponse = await omniscientChatbot.processQuery(
        `Verify this information with current sources: ${message.content}`,
        { requireVerification: true }
      );
      
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? { ...msg, ...verifiedResponse, verified: true }
          : msg
      ));
      
      toast.success('Information verified with current sources');
    } catch (error) {
      toast.error('Verification failed');
    } finally {
      setIsTyping(false);
    }
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      toast.error('Speech recognition not supported');
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      toast.success('Listening...');
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
      toast.error('Speech recognition failed');
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const speakText = (text: string) => {
    if (!voiceEnabled) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);

    speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error('File too large. Please select a file under 10MB.');
        return;
      }
      setSelectedFile(file);
      toast.success(`File "${file.name}" selected`);
    }
  };

  const generateSuggestions = (query: string, source?: string): string[] => {
    const suggestions = [
      "Tell me more about this topic",
      "What are the latest trends?",
      "How does this apply to my career?",
      "Can you provide specific examples?"
    ];
    
    if (source === 'technical') {
      suggestions.push("Show me code examples", "Explain the implementation");
    }
    
    return suggestions.slice(0, 3);
  };

  const getSourceIcon = (source?: string) => {
    switch (source) {
      case 'google': return <Globe className="h-3 w-3" />;
      case 'chatgpt': return <Brain className="h-3 w-3" />;
      case 'deepseek': return <Sparkles className="h-3 w-3" />;
      case 'human': return <Users className="h-3 w-3" />;
      case 'knowledge_base': return <FileText className="h-3 w-3" />;
      default: return <Zap className="h-3 w-3" />;
    }
  };

  const getSourceColor = (source?: string) => {
    switch (source) {
      case 'google': return 'text-blue-400';
      case 'chatgpt': return 'text-green-400';
      case 'deepseek': return 'text-purple-400';
      case 'human': return 'text-orange-400';
      case 'knowledge_base': return 'text-gray-400';
      default: return 'text-cyan-400';
    }
  };

  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return 'text-gray-400';
    if (confidence >= 0.8) return 'text-green-400';
    if (confidence >= 0.6) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-4 z-50 flex items-center justify-center"
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      
      <GlassPanel className="relative w-full max-w-5xl h-full max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <Avatar3D size="sm" />
            <div>
              <h3 className="text-lg font-semibold text-white">Omniscient AI Assistant</h3>
              <div className="flex items-center space-x-4 text-sm text-gray-300">
                <span className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span>Multi-AI Powered</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Shield className="h-3 w-3" />
                  <span>Verified Sources</span>
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setVerificationMode(!verificationMode)}
              className={`p-2 rounded-lg transition-colors ${
                verificationMode ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
              }`}
              title="Always verify with Google"
            >
              <CheckCircle className="h-4 w-4" />
            </motion.button>
            
            <button
              onClick={isSpeaking ? stopSpeaking : () => {}}
              className={`p-2 rounded-lg transition-colors ${
                isSpeaking ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'
              }`}
            >
              {isSpeaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                <GlassPanel 
                  className={`p-4 ${
                    message.sender === 'user' 
                      ? 'bg-blue-500/20 border-blue-400/30' 
                      : 'bg-gray-500/20 border-gray-400/30'
                  }`}
                >
                  {message.sender === 'bot' && (
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {message.source && (
                          <div className={`flex items-center space-x-1 text-xs ${getSourceColor(message.source)}`}>
                            {getSourceIcon(message.source)}
                            <span className="capitalize">{message.source.replace('_', ' ')}</span>
                          </div>
                        )}
                        {message.verified && (
                          <div className="flex items-center space-x-1 text-xs text-green-400">
                            <CheckCircle className="h-3 w-3" />
                            <span>Verified</span>
                          </div>
                        )}
                      </div>
                      
                      {message.confidence && (
                        <div className={`text-xs ${getConfidenceColor(message.confidence)}`}>
                          {Math.round(message.confidence * 100)}% confidence
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="text-white text-sm leading-relaxed whitespace-pre-wrap">
                    {message.content}
                  </div>
                  
                  {message.citations && message.citations.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-white/10">
                      <p className="text-xs text-gray-400 mb-2">Sources:</p>
                      <div className="space-y-2">
                        {message.citations.map((citation, index) => (
                          <a
                            key={index}
                            href={citation.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-start space-x-2 text-xs text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            <ExternalLink className="h-3 w-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <div className="font-medium">{citation.title}</div>
                              <div className="text-gray-400">{citation.source}</div>
                            </div>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {message.suggestions && (
                    <div className="mt-4 pt-3 border-t border-white/10">
                      <p className="text-xs text-gray-400 mb-2">Suggested follow-ups:</p>
                      <div className="flex flex-wrap gap-2">
                        {message.suggestions.map((suggestion, index) => (
                          <motion.button
                            key={index}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => handleSendMessage(suggestion)}
                            className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
                          >
                            {suggestion}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {message.sender === 'bot' && (
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/10">
                      <div className="flex items-center space-x-2">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleRateMessage(message.id, 5)}
                          className={`p-1 rounded transition-colors ${
                            message.rating === 5 ? 'text-green-400' : 'text-gray-400 hover:text-green-400'
                          }`}
                        >
                          <ThumbsUp className="h-3 w-3" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleRateMessage(message.id, 1)}
                          className={`p-1 rounded transition-colors ${
                            message.rating === 1 ? 'text-red-400' : 'text-gray-400 hover:text-red-400'
                          }`}
                        >
                          <ThumbsDown className="h-3 w-3" />
                        </motion.button>
                      </div>
                      
                      {!message.verified && message.confidence && message.confidence < 0.8 && (
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleVerifyWithGoogle(message.id)}
                          className="flex items-center space-x-1 px-2 py-1 text-xs bg-blue-500/20 text-blue-400 rounded-full hover:bg-blue-500/30 transition-colors"
                        >
                          <Search className="h-3 w-3" />
                          <span>Verify with Google</span>
                        </motion.button>
                      )}
                    </div>
                  )}
                </GlassPanel>
                
                <p className="text-xs text-gray-400 mt-1 px-2">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
              
              {message.sender === 'bot' && (
                <div className="order-1 mr-3">
                  <Avatar3D size="sm" />
                </div>
              )}
            </motion.div>
          ))}
          
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="flex items-center space-x-3">
                <Avatar3D size="sm" />
                <GlassPanel className="p-4 bg-gray-500/20">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                        className="w-2 h-2 bg-white/60 rounded-full"
                      />
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                        className="w-2 h-2 bg-white/60 rounded-full"
                      />
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                        className="w-2 h-2 bg-white/60 rounded-full"
                      />
                    </div>
                    <span className="text-xs text-gray-300">AI is thinking...</span>
                  </div>
                </GlassPanel>
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 border-t border-white/10">
          {selectedFile && (
            <div className="mb-3 p-3 bg-blue-500/20 rounded-lg flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 text-blue-400" />
                <span className="text-sm text-white">{selectedFile.name}</span>
              </div>
              <button
                onClick={() => setSelectedFile(null)}
                className="text-gray-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
          
          <div className="flex items-center space-x-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx,.txt,image/*"
              className="hidden"
            />
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-gray-400 hover:text-white transition-colors"
            >
              <Paperclip className="h-5 w-5" />
            </button>
            
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
                placeholder="Ask me anything about careers, interviews, market trends, or technical topics..."
                className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <button
              onClick={isListening ? () => {} : startListening}
              className={`p-3 rounded-lg transition-colors ${
                isListening 
                  ? 'bg-red-500/20 text-red-400 animate-pulse' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSendMessage(inputValue)}
              disabled={!inputValue.trim() && !selectedFile}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-lg transition-colors"
            >
              <Send className="h-5 w-5" />
            </motion.button>
          </div>
          
          {verificationMode && (
            <div className="mt-2 flex items-center space-x-2 text-xs text-green-400">
              <AlertTriangle className="h-3 w-3" />
              <span>Verification mode enabled - all responses will be fact-checked</span>
            </div>
          )}
        </div>
      </GlassPanel>
    </motion.div>
  );
};

export default OmnichannelChatbot;