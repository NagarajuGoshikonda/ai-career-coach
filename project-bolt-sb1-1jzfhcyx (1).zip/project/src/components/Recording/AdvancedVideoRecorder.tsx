import React, { useRef, useEffect, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { motion, AnimatePresence } from 'framer-motion';
import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';
import { 
  Play, 
  Square, 
  Pause, 
  Video, 
  Mic, 
  MicOff, 
  VideoOff, 
  AlertCircle, 
  CheckCircle,
  Loader2,
  Volume2,
  RotateCcw,
  TestTube,
  Wifi,
  WifiOff,
  HardDrive,
  Trash2,
  Settings
} from 'lucide-react';
import toast from 'react-hot-toast';
import confetti from 'canvas-confetti';
import GlassPanel from '../UI/GlassPanel';
import { useAppStore } from '../../stores/appStore';

interface AdvancedVideoRecorderProps {
  onAnalysisComplete?: (analysis: any, audioUrl?: string) => void;
  question: string;
  questionId: string;
}

interface RecordingState {
  isRecording: boolean;
  isPaused: boolean;
  duration: number;
  error: string | null;
  isInitializing: boolean;
  hasPermission: boolean;
  stream: MediaStream | null;
  uploadProgress: number;
  retryCount: number;
  isProcessing: boolean;
  nervousnessPulse: number;
  fillerWordCount: number;
  liveTranscript: string;
}

const AdvancedVideoRecorder = ({ 
  onAnalysisComplete, 
  question, 
  questionId 
}: AdvancedVideoRecorderProps) => {
  const webcamRef = useRef<Webcam>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const ffmpegRef = useRef<FFmpeg>(new FFmpeg());
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { isOfflineMode, recordingQuality, setOfflineMode } = useAppStore();
  
  const [state, setState] = useState<RecordingState>({
    isRecording: false,
    isPaused: false,
    duration: 0,
    error: null,
    isInitializing: false,
    hasPermission: false,
    stream: null,
    uploadProgress: 0,
    retryCount: 0,
    isProcessing: false,
    nervousnessPulse: 50,
    fillerWordCount: 0,
    liveTranscript: ''
  });

  const updateState = useCallback((updates: Partial<RecordingState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  // Initialize FFmpeg
  useEffect(() => {
    const loadFFmpeg = async () => {
      try {
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
        const ffmpeg = ffmpegRef.current;
        
        await ffmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });
      } catch (error) {
        console.error('FFmpeg loading error:', error);
      }
    };

    loadFFmpeg();
  }, []);

  // Nervousness pulse simulation
  useEffect(() => {
    if (state.isRecording && !state.isPaused) {
      const interval = setInterval(() => {
        updateState({ 
          nervousnessPulse: Math.random() * 40 + 30,
          fillerWordCount: state.fillerWordCount + (Math.random() > 0.95 ? 1 : 0)
        });
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [state.isRecording, state.isPaused, state.fillerWordCount, updateState]);

  const initializeCamera = useCallback(async () => {
    updateState({ isInitializing: true, error: null });

    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasCamera = devices.some(device => device.kind === 'videoinput');
      
      if (!hasCamera) {
        throw new Error('No camera found. Please connect a camera and refresh the page.');
      }

      const constraints = {
        video: {
          width: recordingQuality === 'high' ? 1920 : recordingQuality === 'medium' ? 1280 : 640,
          height: recordingQuality === 'high' ? 1080 : recordingQuality === 'medium' ? 720 : 480,
          facingMode: 'user',
          frameRate: recordingQuality === 'high' ? 30 : 24
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);

      updateState({
        stream,
        hasPermission: true,
        isInitializing: false,
        error: null
      });

      toast.success('Camera initialized successfully');
    } catch (error: any) {
      let errorMessage = 'Failed to initialize camera';
      let suggestion = '';
      
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied';
        suggestion = 'Please allow camera access in your browser settings and refresh the page.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'No camera found';
        suggestion = 'Please connect a camera to your device and try again.';
      } else if (error.name === 'NotReadableError') {
        errorMessage = 'Camera is busy';
        suggestion = 'Close other applications using the camera and try again.';
      }

      updateState({
        error: `${errorMessage}. ${suggestion}`,
        isInitializing: false,
        hasPermission: false
      });

      toast.error(errorMessage);
    }
  }, [recordingQuality, updateState]);

  const startRecording = useCallback(async () => {
    if (!state.stream) {
      await initializeCamera();
      return;
    }

    try {
      updateState({ error: null, retryCount: 0 });
      
      const mimeType = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm';
      
      mediaRecorderRef.current = new MediaRecorder(state.stream, {
        mimeType,
        videoBitsPerSecorder: recordingQuality === 'high' ? 5000000 : recordingQuality === 'medium' ? 2500000 : 1000000,
        audioBitsPerSecond: 128000
      });

      chunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        
        if (blob.size === 0) {
          const error = 'Recording failed - no data captured';
          updateState({ error });
          toast.error(error);
          return;
        }

        await handleRecordingComplete(blob);
      };

      mediaRecorderRef.current.start(1000);
      updateState({
        isRecording: true,
        isPaused: false,
        duration: 0,
        fillerWordCount: 0,
        liveTranscript: ''
      });
      
      // Start timer
      timerRef.current = setInterval(() => {
        setState(prev => ({ ...prev, duration: prev.duration + 1 }));
      }, 1000);
      
      toast.success('Recording started');
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to start recording';
      updateState({ error: errorMessage });
      toast.error(errorMessage);
    }
  }, [state.stream, recordingQuality, initializeCamera, updateState]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording) {
      mediaRecorderRef.current.stop();
      updateState({
        isRecording: false,
        isPaused: false
      });
    }

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, [state.isRecording, updateState]);

  const handleRecordingComplete = async (blob: Blob, retryCount = 0) => {
    updateState({ isProcessing: true, uploadProgress: 0 });

    try {
      // Try to upload to Supabase first
      if (!isOfflineMode) {
        try {
          const fileName = `interview-${questionId}-${Date.now()}.mp4`;
          
          // Simulate upload progress
          const progressInterval = setInterval(() => {
            setState(prev => ({
              ...prev,
              uploadProgress: Math.min(prev.uploadProgress + 10, 90)
            }));
          }, 200);

          // Process with FFmpeg if needed
          let processedBlob = blob;
          if (recordingQuality === 'high') {
            processedBlob = await compressVideo(blob);
          }

          const { uploadVideoToSupabase } = await import('../../services/supabase');
          const videoUrl = await uploadVideoToSupabase(processedBlob, fileName);
          
          clearInterval(progressInterval);
          updateState({ uploadProgress: 100 });
          
          toast.success('Video uploaded successfully');
          
          // Analyze with AI
          const analysis = await analyzeVideo(videoUrl);
          updateState({ isProcessing: false });
          
          // Trigger confetti for high scores
          if (analysis.overall_score >= 80) {
            confetti({
              particleCount: 100,
              spread: 70,
              origin: { y: 0.6 }
            });
          }
          
          onAnalysisComplete?.(analysis);
          
        } catch (uploadError) {
          console.error('Upload failed:', uploadError);
          
          if (retryCount < 3) {
            toast.error(`Upload failed, retrying... (${retryCount + 1}/3)`);
            updateState({ retryCount: retryCount + 1 });
            setTimeout(() => handleRecordingComplete(blob, retryCount + 1), 2000);
            return;
          } else {
            toast.error('Upload failed, switching to offline mode');
            setOfflineMode(true);
          }
        }
      }

      // Fallback to browser storage
      if (isOfflineMode || retryCount >= 3) {
        const fileName = `offline-recording-${Date.now()}`;
        await saveToIndexedDB(blob, fileName);
        
        const analysis = getMockAnalysis();
        updateState({ isProcessing: false });
        
        toast.success('Recording saved offline');
        onAnalysisComplete?.(analysis);
      }
      
    } catch (error: any) {
      console.error('Recording processing error:', error);
      updateState({ 
        error: error.message || 'Failed to process recording',
        isProcessing: false 
      });
      toast.error('Failed to process recording');
    }
  };

  const compressVideo = async (blob: Blob): Promise<Blob> => {
    const ffmpeg = ffmpegRef.current;
    
    try {
      await ffmpeg.writeFile('input.mp4', await fetchFile(blob));
      
      await ffmpeg.exec([
        '-i', 'input.mp4',
        '-c:v', 'libx264',
        '-crf', '28',
        '-preset', 'fast',
        '-c:a', 'aac',
        '-b:a', '128k',
        'output.mp4'
      ]);
      
      const data = await ffmpeg.readFile('output.mp4');
      return new Blob([data], { type: 'video/mp4' });
    } catch (error) {
      console.error('Video compression failed:', error);
      return blob; // Return original if compression fails
    }
  };

  const saveToIndexedDB = async (blob: Blob, fileName: string) => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('VideoRecordings', 1);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['recordings'], 'readwrite');
        const store = transaction.objectStore('recordings');
        
        store.add({
          id: fileName,
          blob: blob,
          timestamp: Date.now(),
          questionId
        });
        
        transaction.oncomplete = () => resolve(fileName);
        transaction.onerror = () => reject(transaction.error);
      };
      
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('recordings')) {
          db.createObjectStore('recordings', { keyPath: 'id' });
        }
      };
    });
  };

  const analyzeVideo = async (videoUrl: string) => {
    // Mock analysis with realistic delays
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    return {
      overall_score: Math.floor(Math.random() * 30) + 70,
      filler_words: state.fillerWordCount,
      eye_contact_percentage: Math.floor(Math.random() * 30) + 70,
      confidence_score: Math.floor(Math.random() * 25) + 70,
      speech_pace: Math.floor(Math.random() * 40) + 140,
      nervousness_level: Math.floor(state.nervousnessPulse),
      recommendations: [
        'Try to reduce filler words by pausing instead',
        'Maintain more consistent eye contact with the camera',
        'Speak with more confidence and conviction',
        'Use more purposeful hand gestures'
      ]
    };
  };

  const getMockAnalysis = () => ({
    overall_score: Math.floor(Math.random() * 30) + 70,
    filler_words: state.fillerWordCount,
    eye_contact_percentage: Math.floor(Math.random() * 30) + 70,
    confidence_score: Math.floor(Math.random() * 25) + 70,
    speech_pace: Math.floor(Math.random() * 40) + 140,
    nervousness_level: Math.floor(state.nervousnessPulse),
    recommendations: [
      'Practice more to improve confidence',
      'Work on reducing nervous habits',
      'Structure answers using STAR method'
    ]
  });

  const clearCache = async () => {
    try {
      const request = indexedDB.open('VideoRecordings', 1);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['recordings'], 'readwrite');
        const store = transaction.objectStore('recordings');
        store.clear();
        toast.success('Cache cleared successfully');
      };
    } catch (error) {
      toast.error('Failed to clear cache');
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <GlassPanel className="overflow-hidden">
      {/* Question header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">
              Practice Question
            </h3>
            <p className="text-gray-300">{question}</p>
          </div>
          
          {/* Status indicators */}
          <div className="flex items-center space-x-3">
            {isOfflineMode ? (
              <div className="flex items-center space-x-1 text-orange-400">
                <WifiOff className="h-4 w-4" />
                <span className="text-xs">Offline</span>
              </div>
            ) : (
              <div className="flex items-center space-x-1 text-green-400">
                <Wifi className="h-4 w-4" />
                <span className="text-xs">Online</span>
              </div>
            )}
            
            <button
              onClick={clearCache}
              className="p-2 text-gray-400 hover:text-white transition-colors"
              title="Clear cache"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Video area */}
      <div className="relative bg-black/20 aspect-video">
        {!state.hasPermission && !state.isInitializing ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center text-white p-8"
            >
              <Video className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">Camera Access Required</h3>
              <p className="text-gray-300 mb-4">
                Please allow camera and microphone access to start recording
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={initializeCamera}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Enable Camera
              </motion.button>
            </motion.div>
          </div>
        ) : state.isInitializing ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
              <p>Initializing camera...</p>
            </div>
          </div>
        ) : state.error ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center text-white p-8"
            >
              <AlertCircle className="h-16 w-16 mx-auto mb-4 text-red-500" />
              <h3 className="text-lg font-semibold mb-2">Camera Error</h3>
              <p className="text-gray-300 mb-4 max-w-md">{state.error}</p>
              <div className="space-x-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={initializeCamera}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  <RotateCcw className="h-4 w-4 inline mr-2" />
                  Retry
                </motion.button>
              </div>
            </motion.div>
          </div>
        ) : (
          <Webcam
            ref={webcamRef}
            audio={true}
            video={true}
            mirrored={true}
            className="w-full h-full object-cover"
            videoConstraints={{
              width: recordingQuality === 'high' ? 1920 : recordingQuality === 'medium' ? 1280 : 640,
              height: recordingQuality === 'high' ? 1080 : recordingQuality === 'medium' ? 720 : 480,
              facingMode: 'user'
            }}
          />
        )}
        
        {/* Live feedback overlay */}
        <AnimatePresence>
          {state.isRecording && !state.isPaused && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 left-4 right-4 flex justify-between items-start"
            >
              {/* Recording indicator */}
              <div className="bg-red-600/80 backdrop-blur-sm text-white px-3 py-1 rounded-full flex items-center space-x-2">
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-2 h-2 bg-white rounded-full"
                />
                <span className="text-sm font-medium">REC {formatDuration(state.duration)}</span>
              </div>

              {/* Live metrics */}
              <div className="space-y-2">
                {/* Nervousness pulse */}
                <GlassPanel className="px-3 py-1 text-xs">
                  <div className="flex items-center space-x-2">
                    <span className="text-white">Nervousness:</span>
                    <div className="w-16 h-1 bg-gray-600 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-green-400 to-red-400"
                        style={{ width: `${state.nervousnessPulse}%` }}
                        animate={{ width: `${state.nervousnessPulse}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>
                  </div>
                </GlassPanel>

                {/* Filler words */}
                <GlassPanel className="px-3 py-1 text-xs">
                  <span className="text-white">Filler words: {state.fillerWordCount}</span>
                </GlassPanel>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Upload progress */}
        <AnimatePresence>
          {state.isProcessing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/75 flex items-center justify-center"
            >
              <div className="text-center text-white">
                <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Processing Recording...</h3>
                <div className="w-64 h-2 bg-gray-600 rounded-full overflow-hidden mb-2">
                  <motion.div
                    className="h-full bg-blue-500"
                    style={{ width: `${state.uploadProgress}%` }}
                    animate={{ width: `${state.uploadProgress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-300">{state.uploadProgress}% complete</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Controls */}
        {state.hasPermission && !state.error && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
            <GlassPanel className="px-6 py-3">
              <div className="flex items-center space-x-4">
                {!state.isRecording ? (
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={startRecording}
                    disabled={state.isProcessing}
                    className="bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-4 rounded-full transition-colors shadow-lg"
                  >
                    <Play className="h-6 w-6" />
                  </motion.button>
                ) : (
                  <div className="flex items-center space-x-2">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={state.isPaused ? () => {} : () => {}}
                      className="bg-yellow-600 hover:bg-yellow-700 text-white p-3 rounded-full transition-colors"
                    >
                      {state.isPaused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={stopRecording}
                      className="bg-gray-600 hover:bg-gray-700 text-white p-3 rounded-full transition-colors"
                    >
                      <Square className="h-5 w-5" />
                    </motion.button>
                  </div>
                )}
              </div>
            </GlassPanel>
          </div>
        )}
      </div>

      {/* Live transcript */}
      <AnimatePresence>
        {state.isRecording && state.liveTranscript && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-4 border-t border-white/10"
          >
            <h4 className="text-sm font-medium text-white mb-2">Live Transcript:</h4>
            <p className="text-sm text-gray-300">{state.liveTranscript}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Instructions */}
      <div className="p-6 border-t border-white/10">
        <div className="flex items-start space-x-3">
          <div className="bg-blue-500/20 p-2 rounded-lg">
            <Video className="h-4 w-4 text-blue-400" />
          </div>
          <div>
            <h4 className="text-sm font-medium text-white mb-1">
              Recording Tips
            </h4>
            <ul className="text-xs text-gray-300 space-y-1">
              <li>• Ensure good lighting and clear audio</li>
              <li>• Look directly at the camera for eye contact</li>
              <li>• Take your time and speak clearly</li>
              <li>• Use the STAR method if applicable</li>
              <li>• Keep responses between 1-3 minutes</li>
            </ul>
          </div>
        </div>
      </div>
    </GlassPanel>
  );
};

export default AdvancedVideoRecorder;