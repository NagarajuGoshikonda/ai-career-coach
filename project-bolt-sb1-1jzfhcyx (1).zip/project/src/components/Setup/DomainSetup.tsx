import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Globe, 
  ExternalLink, 
  Copy, 
  CheckCircle, 
  AlertCircle,
  Zap,
  Gift,
  Crown,
  ArrowRight
} from 'lucide-react';
import GlassPanel from '../UI/GlassPanel';
import toast from 'react-hot-toast';

const DomainSetup = () => {
  const [selectedOption, setSelectedOption] = useState<string>('freenom');
  const [copiedText, setCopiedText] = useState<string>('');

  const nameservers = [
    'dns1.p08.nsone.net',
    'dns2.p08.nsone.net', 
    'dns3.p08.nsone.net',
    'dns4.p08.nsone.net'
  ];

  const domainSuggestions = [
    'aicareercoach.tk',
    'interviewpro.ml',
    'careerboost.ga',
    'jobreadyai.cf',
    'interviewace.tk',
    'futurecareer.ml',
    'smartinterview.tk',
    'careerlaunch.ga'
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopiedText(''), 2000);
  };

  const domainOptions = [
    {
      id: 'freenom',
      name: 'Freenom',
      description: 'Completely free domains for 1 year',
      extensions: ['.tk', '.ml', '.ga', '.cf'],
      pros: ['100% Free', 'No credit card required', 'Instant activation'],
      cons: ['Limited extensions', 'May have ads'],
      url: 'https://freenom.com',
      recommended: true
    },
    {
      id: 'dottk',
      name: 'Dot.tk',
      description: 'Free .tk domains',
      extensions: ['.tk'],
      pros: ['Simple registration', 'No ads', 'Fast setup'],
      cons: ['Only .tk extension'],
      url: 'http://dot.tk',
      recommended: false
    },
    {
      id: 'subdomain',
      name: 'Free Subdomains',
      description: 'Instant setup with hosting providers',
      extensions: ['.vercel.app', '.netlify.app', '.github.io'],
      pros: ['Instant setup', 'No registration', 'Professional'],
      cons: ['Longer URLs', 'Provider branding'],
      url: '#',
      recommended: false
    }
  ];

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
          Get Your Free Domain Now! 🚀
        </h1>
        <p className="text-gray-300 text-lg">
          Transform your AI Career Coach from a demo to a professional website
        </p>
      </motion.div>

      {/* Quick Start */}
      <GlassPanel className="p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Zap className="h-6 w-6 text-yellow-400" />
          <h2 className="text-2xl font-bold text-white">Quick Start (5 Minutes)</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-blue-500/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl font-bold text-blue-400">1</span>
            </div>
            <h3 className="font-semibold text-white mb-2">Choose Domain</h3>
            <p className="text-gray-400 text-sm">Pick from our suggestions or create your own</p>
          </div>
          
          <div className="text-center">
            <div className="bg-purple-500/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl font-bold text-purple-400">2</span>
            </div>
            <h3 className="font-semibold text-white mb-2">Register Free</h3>
            <p className="text-gray-400 text-sm">Sign up at Freenom with our nameservers</p>
          </div>
          
          <div className="text-center">
            <div className="bg-green-500/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl font-bold text-green-400">3</span>
            </div>
            <h3 className="font-semibold text-white mb-2">Go Live</h3>
            <p className="text-gray-400 text-sm">Connect to Netlify and you're done!</p>
          </div>
        </div>
      </GlassPanel>

      {/* Domain Options */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {domainOptions.map((option) => (
          <motion.div
            key={option.id}
            whileHover={{ scale: 1.02 }}
            className={`cursor-pointer ${selectedOption === option.id ? 'ring-2 ring-blue-500' : ''}`}
            onClick={() => setSelectedOption(option.id)}
          >
            <GlassPanel className={`p-6 h-full ${option.recommended ? 'border-yellow-400/50' : ''}`}>
              {option.recommended && (
                <div className="flex items-center space-x-2 mb-4">
                  <Crown className="h-4 w-4 text-yellow-400" />
                  <span className="text-yellow-400 text-sm font-medium">Recommended</span>
                </div>
              )}
              
              <h3 className="text-xl font-bold text-white mb-2">{option.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{option.description}</p>
              
              <div className="mb-4">
                <p className="text-xs text-gray-500 mb-2">Available extensions:</p>
                <div className="flex flex-wrap gap-2">
                  {option.extensions.map((ext) => (
                    <span key={ext} className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full">
                      {ext}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-green-400 mb-1">Pros:</p>
                  <ul className="text-xs text-gray-400 space-y-1">
                    {option.pros.map((pro, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-3 w-3 text-green-400" />
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <p className="text-xs text-orange-400 mb-1">Cons:</p>
                  <ul className="text-xs text-gray-400 space-y-1">
                    {option.cons.map((con, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <AlertCircle className="h-3 w-3 text-orange-400" />
                        <span>{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              {option.url !== '#' && (
                <motion.a
                  href={option.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="mt-6 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2"
                >
                  <span>Register Now</span>
                  <ExternalLink className="h-4 w-4" />
                </motion.a>
              )}
            </GlassPanel>
          </motion.div>
        ))}
      </div>

      {/* Domain Suggestions */}
      <GlassPanel className="p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Gift className="h-6 w-6 text-green-400" />
          <h2 className="text-2xl font-bold text-white">Perfect Domain Suggestions</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {domainSuggestions.map((domain) => (
            <motion.div
              key={domain}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => copyToClipboard(domain)}
              className="bg-white/5 p-4 rounded-lg border border-white/10 hover:border-white/20 transition-all cursor-pointer text-center"
            >
              <Globe className="h-6 w-6 text-blue-400 mx-auto mb-2" />
              <p className="text-white font-medium text-sm">{domain}</p>
              <p className="text-gray-400 text-xs mt-1">Click to copy</p>
              {copiedText === domain && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-2"
                >
                  <CheckCircle className="h-4 w-4 text-green-400 mx-auto" />
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </GlassPanel>

      {/* Nameservers */}
      <GlassPanel className="p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Globe className="h-6 w-6 text-purple-400" />
          <h2 className="text-2xl font-bold text-white">Netlify Nameservers</h2>
          <span className="text-sm text-gray-400">(Copy these during registration)</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {nameservers.map((ns, index) => (
            <motion.div
              key={ns}
              whileHover={{ scale: 1.02 }}
              onClick={() => copyToClipboard(ns)}
              className="bg-white/5 p-4 rounded-lg border border-white/10 hover:border-white/20 transition-all cursor-pointer flex items-center justify-between"
            >
              <div>
                <p className="text-white font-mono text-sm">{ns}</p>
                <p className="text-gray-400 text-xs">Nameserver {index + 1}</p>
              </div>
              <div className="flex items-center space-x-2">
                {copiedText === ns ? (
                  <CheckCircle className="h-4 w-4 text-green-400" />
                ) : (
                  <Copy className="h-4 w-4 text-gray-400" />
                )}
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => copyToClipboard(nameservers.join('\n'))}
          className="mt-4 w-full bg-purple-600 hover:bg-purple-700 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
        >
          <Copy className="h-4 w-4" />
          <span>Copy All Nameservers</span>
        </motion.button>
      </GlassPanel>

      {/* Step by Step */}
      <GlassPanel className="p-8">
        <h2 className="text-2xl font-bold text-white mb-6">Step-by-Step Instructions</h2>
        
        <div className="space-y-6">
          <div className="flex items-start space-x-4">
            <div className="bg-blue-500/20 p-2 rounded-full">
              <span className="text-blue-400 font-bold">1</span>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">Go to Freenom.com</h3>
              <p className="text-gray-400 text-sm mb-3">Visit freenom.com and search for your chosen domain name</p>
              <motion.a
                href="https://freenom.com"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors"
              >
                <span>Open Freenom</span>
                <ExternalLink className="h-4 w-4" />
              </motion.a>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="bg-purple-500/20 p-2 rounded-full">
              <span className="text-purple-400 font-bold">2</span>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">Register with Nameservers</h3>
              <p className="text-gray-400 text-sm">When registering, choose "Use DNS" and enter the Netlify nameservers above</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="bg-green-500/20 p-2 rounded-full">
              <span className="text-green-400 font-bold">3</span>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">Connect to Netlify</h3>
              <p className="text-gray-400 text-sm">In your Netlify dashboard, add the custom domain and wait for DNS propagation</p>
            </div>
          </div>
        </div>
      </GlassPanel>

      {/* Current Status */}
      <GlassPanel className="p-8 text-center">
        <h2 className="text-2xl font-bold text-white mb-4">Your App is Ready! 🎉</h2>
        <p className="text-gray-300 mb-6">
          Your AI Career Coach is already deployed and working perfectly. 
          A custom domain will make it even more professional!
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-green-500/20 p-4 rounded-lg">
            <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
            <p className="text-white font-medium">Fully Deployed</p>
            <p className="text-gray-400 text-sm">Live on Netlify</p>
          </div>
          
          <div className="bg-blue-500/20 p-4 rounded-lg">
            <CheckCircle className="h-8 w-8 text-blue-400 mx-auto mb-2" />
            <p className="text-white font-medium">Production Ready</p>
            <p className="text-gray-400 text-sm">All features working</p>
          </div>
          
          <div className="bg-purple-500/20 p-4 rounded-lg">
            <CheckCircle className="h-8 w-8 text-purple-400 mx-auto mb-2" />
            <p className="text-white font-medium">Professional Design</p>
            <p className="text-gray-400 text-sm">Beautiful UI/UX</p>
          </div>
        </div>
        
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-all"
        >
          <span>Get Your Domain Now</span>
          <ArrowRight className="h-4 w-4" />
        </motion.div>
      </GlassPanel>
    </div>
  );
};

export default DomainSetup;