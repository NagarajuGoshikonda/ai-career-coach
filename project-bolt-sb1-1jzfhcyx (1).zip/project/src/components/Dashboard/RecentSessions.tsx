import React from 'react';
import { Play, Clock, TrendingUp } from 'lucide-react';

interface Session {
  id: string;
  question: string;
  score: number;
  duration: string;
  date: string;
  category: string;
}

const RecentSessions = () => {
  const sessions: Session[] = [
    {
      id: '1',
      question: 'Tell me about yourself',
      score: 85,
      duration: '3:45',
      date: '2 hours ago',
      category: 'General'
    },
    {
      id: '2',
      question: 'Describe a challenging project',
      score: 72,
      duration: '4:20',
      date: '1 day ago',
      category: 'Behavioral'
    },
    {
      id: '3',
      question: 'Where do you see yourself in 5 years?',
      score: 89,
      duration: '2:30',
      date: '2 days ago',
      category: 'General'
    },
    {
      id: '4',
      question: 'Tell me about a time you led a team',
      score: 76,
      duration: '5:15',
      date: '3 days ago',
      category: 'Leadership'
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success-600 dark:text-success-400 bg-success-100 dark:bg-success-900/30';
    if (score >= 60) return 'text-warning-600 dark:text-warning-400 bg-warning-100 dark:bg-warning-900/30';
    return 'text-error-600 dark:text-error-400 bg-error-100 dark:bg-error-900/30';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Sessions</h3>
        <button className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 text-sm font-medium">
          View All
        </button>
      </div>

      <div className="space-y-4">
        {sessions.map((session) => (
          <div key={session.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer">
            <div className="flex items-center space-x-4">
              <div className="bg-primary-100 dark:bg-primary-900/30 p-2 rounded-lg">
                <Play className="h-4 w-4 text-primary-600 dark:text-primary-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  {session.question}
                </p>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {session.duration}
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {session.date}
                  </span>
                  <span className="text-xs px-2 py-1 bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-full">
                    {session.category}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className={`inline-flex items-center px-2 py-1 rounded-full text-sm font-medium ${getScoreColor(session.score)}`}>
                <TrendingUp className="h-3 w-3 mr-1" />
                {session.score}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentSessions;