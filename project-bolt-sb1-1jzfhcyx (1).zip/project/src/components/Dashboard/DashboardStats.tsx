import React from 'react';
import { TrendingUp, Clock, Target, Award } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ComponentType<any>;
  positive?: boolean;
}

const StatsCard = ({ title, value, change, icon: Icon, positive = true }: StatsCardProps) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
        <p className={`text-sm mt-1 ${positive ? 'text-success-600 dark:text-success-400' : 'text-error-600 dark:text-error-400'}`}>
          {change}
        </p>
      </div>
      <div className="bg-primary-100 dark:bg-primary-900/30 p-3 rounded-lg">
        <Icon className="h-6 w-6 text-primary-600 dark:text-primary-400" />
      </div>
    </div>
  </div>
);

const DashboardStats = () => {
  const stats = [
    {
      title: 'Overall Score',
      value: '78',
      change: '+12% from last week',
      icon: Award,
      positive: true
    },
    {
      title: 'Sessions Completed',
      value: '24',
      change: '+8 this week',
      icon: Target,
      positive: true
    },
    {
      title: 'Practice Time',
      value: '2h 15m',
      change: '+45m this week',
      icon: Clock,
      positive: true
    },
    {
      title: 'Improvement Rate',
      value: '15%',
      change: '+3% this month',
      icon: TrendingUp,
      positive: true
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <StatsCard key={index} {...stat} />
      ))}
    </div>
  );
};

export default DashboardStats;