import { useState, useRef, useCallback } from 'react';
import toast from 'react-hot-toast';

interface UseVideoRecorderOptions {
  onRecordingComplete?: (blob: Blob) => void;
  onError?: (error: string) => void;
}

export interface VideoRecorderState {
  isRecording: boolean;
  isPaused: boolean;
  duration: number;
  error: string | null;
  isInitializing: boolean;
  hasPermission: boolean;
  stream: MediaStream | null;
}

export const useVideoRecorder = (options: UseVideoRecorderOptions = {}) => {
  const [state, setState] = useState<VideoRecorderState>({
    isRecording: false,
    isPaused: false,
    duration: 0,
    error: null,
    isInitializing: false,
    hasPermission: false,
    stream: null,
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const updateState = useCallback((updates: Partial<VideoRecorderState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  const startTimer = useCallback(() => {
    timerRef.current = setInterval(() => {
      setState(prev => ({ ...prev, duration: prev.duration + 1 }));
    }, 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const initializeCamera = useCallback(async () => {
    updateState({ isInitializing: true, error: null });

    try {
      // Check if camera is available
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasCamera = devices.some(device => device.kind === 'videoinput');
      
      if (!hasCamera) {
        throw new Error('No camera found on this device');
      }

      // Request permissions
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        }
      });

      streamRef.current = stream;
      updateState({
        stream,
        hasPermission: true,
        isInitializing: false,
        error: null
      });

      toast.success('Camera initialized successfully');
    } catch (error: any) {
      let errorMessage = 'Failed to initialize camera';
      
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied. Please allow camera access and try again.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'No camera found on this device.';
      } else if (error.name === 'NotReadableError') {
        errorMessage = 'Camera is already in use by another application.';
      }

      updateState({
        error: errorMessage,
        isInitializing: false,
        hasPermission: false
      });

      options.onError?.(errorMessage);
      toast.error(errorMessage);
    }
  }, [options, updateState]);

  const startRecording = useCallback(async () => {
    if (!streamRef.current) {
      await initializeCamera();
      return;
    }

    try {
      updateState({ error: null });
      
      // Check if MediaRecorder is supported
      if (!MediaRecorder.isTypeSupported('video/mp4')) {
        if (!MediaRecorder.isTypeSupported('video/webm')) {
          throw new Error('Video recording is not supported in this browser');
        }
      }

      const mimeType = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm';
      
      mediaRecorderRef.current = new MediaRecorder(streamRef.current, {
        mimeType,
        videoBitsPerSecond: 2500000, // 2.5 Mbps
        audioBitsPerSecond: 128000   // 128 kbps
      });

      chunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        
        if (blob.size === 0) {
          const error = 'Recording failed - no data captured';
          updateState({ error });
          options.onError?.(error);
          toast.error(error);
          return;
        }

        options.onRecordingComplete?.(blob);
        toast.success('Recording completed successfully');
        stopTimer();
      };

      mediaRecorderRef.current.onerror = (event: any) => {
        const error = `Recording error: ${event.error?.message || 'Unknown error'}`;
        updateState({ error });
        options.onError?.(error);
        toast.error(error);
        stopTimer();
      };

      mediaRecorderRef.current.start(1000); // Collect data every second
      updateState({
        isRecording: true,
        isPaused: false,
        duration: 0
      });
      startTimer();
      
      toast.success('Recording started');
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to start recording';
      updateState({ error: errorMessage });
      options.onError?.(errorMessage);
      toast.error(errorMessage);
    }
  }, [initializeCamera, options, updateState, startTimer, stopTimer]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording) {
      mediaRecorderRef.current.stop();
      updateState({
        isRecording: false,
        isPaused: false
      });
    }
  }, [state.isRecording, updateState]);

  const pauseRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording && !state.isPaused) {
      mediaRecorderRef.current.pause();
      updateState({ isPaused: true });
      stopTimer();
      toast('Recording paused');
    }
  }, [state.isRecording, state.isPaused, updateState, stopTimer]);

  const resumeRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording && state.isPaused) {
      mediaRecorderRef.current.resume();
      updateState({ isPaused: false });
      startTimer();
      toast('Recording resumed');
    }
  }, [state.isRecording, state.isPaused, updateState, startTimer]);

  const cleanup = useCallback(() => {
    stopTimer();
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    updateState({
      stream: null,
      hasPermission: false,
      isRecording: false,
      isPaused: false,
      duration: 0
    });
  }, [stopTimer, updateState]);

  const testRecording = useCallback(async () => {
    try {
      await initializeCamera();
      
      // Start a 3-second test recording
      await startRecording();
      
      setTimeout(() => {
        stopRecording();
        toast.success('Test recording completed successfully!');
      }, 3000);
    } catch (error) {
      toast.error('Test recording failed');
    }
  }, [initializeCamera, startRecording, stopRecording]);

  return {
    ...state,
    initializeCamera,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    cleanup,
    testRecording
  };
};