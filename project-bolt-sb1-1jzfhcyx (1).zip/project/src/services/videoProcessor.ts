import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

class VideoProcessor {
  private ffmpeg: FFmpeg;
  private isLoaded = false;

  constructor() {
    this.ffmpeg = new FFmpeg();
  }

  async initialize() {
    if (this.isLoaded) return;

    try {
      const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
      
      await this.ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      });
      
      this.isLoaded = true;
    } catch (error) {
      console.error('FFmpeg initialization failed:', error);
      throw new Error('Video processing not available');
    }
  }

  async compressVideo(
    blob: Blob, 
    quality: 'low' | 'medium' | 'high' = 'medium'
  ): Promise<Blob> {
    await this.initialize();

    const qualitySettings = {
      low: { crf: '32', preset: 'ultrafast', scale: '640:480' },
      medium: { crf: '28', preset: 'fast', scale: '1280:720' },
      high: { crf: '23', preset: 'medium', scale: '1920:1080' }
    };

    const settings = qualitySettings[quality];

    try {
      await this.ffmpeg.writeFile('input.mp4', await fetchFile(blob));
      
      await this.ffmpeg.exec([
        '-i', 'input.mp4',
        '-c:v', 'libx264',
        '-crf', settings.crf,
        '-preset', settings.preset,
        '-vf', `scale=${settings.scale}`,
        '-c:a', 'aac',
        '-b:a', '128k',
        '-movflags', '+faststart',
        'output.mp4'
      ]);
      
      const data = await this.ffmpeg.readFile('output.mp4');
      return new Blob([data], { type: 'video/mp4' });
    } catch (error) {
      console.error('Video compression failed:', error);
      return blob; // Return original if compression fails
    }
  }

  async extractThumbnail(blob: Blob, timeInSeconds = 1): Promise<Blob> {
    await this.initialize();

    try {
      await this.ffmpeg.writeFile('input.mp4', await fetchFile(blob));
      
      await this.ffmpeg.exec([
        '-i', 'input.mp4',
        '-ss', timeInSeconds.toString(),
        '-vframes', '1',
        '-vf', 'scale=320:240',
        'thumbnail.jpg'
      ]);
      
      const data = await this.ffmpeg.readFile('thumbnail.jpg');
      return new Blob([data], { type: 'image/jpeg' });
    } catch (error) {
      console.error('Thumbnail extraction failed:', error);
      throw new Error('Failed to extract thumbnail');
    }
  }

  async getVideoInfo(blob: Blob): Promise<{
    duration: number;
    width: number;
    height: number;
    size: number;
  }> {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      
      video.onloadedmetadata = () => {
        resolve({
          duration: video.duration,
          width: video.videoWidth,
          height: video.videoHeight,
          size: blob.size
        });
        URL.revokeObjectURL(video.src);
      };
      
      video.src = URL.createObjectURL(blob);
    });
  }

  async convertToWebM(blob: Blob): Promise<Blob> {
    await this.initialize();

    try {
      await this.ffmpeg.writeFile('input.mp4', await fetchFile(blob));
      
      await this.ffmpeg.exec([
        '-i', 'input.mp4',
        '-c:v', 'libvpx-vp9',
        '-crf', '30',
        '-b:v', '0',
        '-c:a', 'libopus',
        'output.webm'
      ]);
      
      const data = await this.ffmpeg.readFile('output.webm');
      return new Blob([data], { type: 'video/webm' });
    } catch (error) {
      console.error('WebM conversion failed:', error);
      return blob;
    }
  }
}

export const videoProcessor = new VideoProcessor();