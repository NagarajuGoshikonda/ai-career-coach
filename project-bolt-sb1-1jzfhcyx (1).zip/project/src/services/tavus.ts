interface TavusAnalysisResult {
  filler_words: number;
  eye_contact_percentage: number;
  confidence_score: number;
  speech_pace: number;
  posture_score: number;
  gesture_score: number;
  overall_score: number;
  recommendations: string[];
}

interface TavusResponse {
  analysis: TavusAnalysisResult;
  status: 'completed' | 'processing' | 'failed';
  job_id: string;
}

const TAVUS_API_KEY = import.meta.env.VITE_TAVUS_API_KEY;
const TAVUS_BASE_URL = 'https://api.tavus.io/v1';

export const analyzeVideoWithTavus = async (videoUrl: string): Promise<TavusAnalysisResult> => {
  try {
    // Submit video for analysis
    const submitResponse = await fetch(`${TAVUS_BASE_URL}/analyze`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${TAVUS_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        video_url: videoUrl,
        analysis_type: 'interview_coaching',
        features: [
          'speech_analysis',
          'body_language',
          'eye_contact',
          'confidence_detection'
        ]
      }),
    });

    if (!submitResponse.ok) {
      throw new Error(`Tavus API error: ${submitResponse.status}`);
    }

    const submitData = await submitResponse.json();
    const jobId = submitData.job_id;

    // Poll for results
    return await pollTavusResults(jobId);
  } catch (error) {
    console.error('Tavus analysis error:', error);
    
    // Return mock data for development/testing
    if (import.meta.env.DEV) {
      return getMockTavusAnalysis();
    }
    
    throw new Error('Failed to analyze video with Tavus AI');
  }
};

const pollTavusResults = async (jobId: string, maxAttempts = 30): Promise<TavusAnalysisResult> => {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const response = await fetch(`${TAVUS_BASE_URL}/analyze/${jobId}`, {
        headers: {
          'Authorization': `Bearer ${TAVUS_API_KEY}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Tavus polling error: ${response.status}`);
      }

      const data: TavusResponse = await response.json();

      if (data.status === 'completed') {
        return data.analysis;
      } else if (data.status === 'failed') {
        throw new Error('Tavus analysis failed');
      }

      // Wait 2 seconds before next poll
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (error) {
      if (attempt === maxAttempts - 1) {
        throw error;
      }
    }
  }

  throw new Error('Tavus analysis timeout');
};

export const getMockTavusAnalysis = (): TavusAnalysisResult => ({
  filler_words: Math.floor(Math.random() * 10) + 2,
  eye_contact_percentage: Math.floor(Math.random() * 30) + 70,
  confidence_score: Math.floor(Math.random() * 20) + 75,
  speech_pace: Math.floor(Math.random() * 40) + 140,
  posture_score: Math.floor(Math.random() * 25) + 70,
  gesture_score: Math.floor(Math.random() * 30) + 65,
  overall_score: Math.floor(Math.random() * 20) + 75,
  recommendations: [
    'Try to reduce filler words by pausing instead',
    'Maintain more consistent eye contact with the camera',
    'Speak with more confidence and conviction',
    'Use more purposeful hand gestures to emphasize points'
  ]
});