import { createClient } from '@supabase/supabase-js';
import { offlineStorage } from './offlineStorage';
import { videoProcessor } from './videoProcessor';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

// Check if Supabase is properly configured
const isSupabaseConfigured = () => {
  return supabaseUrl !== 'https://your-project.supabase.co' && 
         supabaseAnonKey !== 'your-anon-key' &&
         supabaseUrl.includes('supabase.co');
};

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

interface UploadOptions {
  quality?: 'low' | 'medium' | 'high';
  retryCount?: number;
  onProgress?: (progress: number) => void;
  fallbackToOffline?: boolean;
}

export const uploadVideoToSupabase = async (
  videoBlob: Blob, 
  fileName: string,
  options: UploadOptions = {}
): Promise<string> => {
  const {
    quality = 'medium',
    retryCount = 3,
    onProgress,
    fallbackToOffline = true
  } = options;

  // Check if Supabase is configured
  if (!isSupabaseConfigured()) {
    if (fallbackToOffline) {
      return await fallbackToOfflineStorage(videoBlob, fileName, quality);
    }
    throw new Error(
      'Supabase is not configured. Please set up your VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables.'
    );
  }

  // Check network connectivity
  if (!navigator.onLine && fallbackToOffline) {
    return await fallbackToOfflineStorage(videoBlob, fileName, quality);
  }

  let processedBlob = videoBlob;
  
  try {
    // Compress video based on quality setting
    onProgress?.(10);
    if (quality !== 'high') {
      processedBlob = await videoProcessor.compressVideo(videoBlob, quality);
    }
    onProgress?.(30);

    // Attempt upload with retries
    for (let attempt = 1; attempt <= retryCount; attempt++) {
      try {
        onProgress?.(30 + (attempt - 1) * 20);
        
        // Check if bucket exists
        const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets();
        
        if (bucketsError) {
          throw new Error(`Storage access error: ${bucketsError.message}`);
        }

        const bucketExists = buckets?.some(bucket => bucket.name === 'interview-recordings');
        if (!bucketExists) {
          throw new Error('Storage bucket "interview-recordings" does not exist');
        }

        // Upload file
        const { data, error } = await supabase.storage
          .from('interview-recordings')
          .upload(fileName, processedBlob, {
            contentType: 'video/mp4',
            upsert: false
          });

        if (error) {
          throw new Error(`Upload failed: ${error.message}`);
        }

        onProgress?.(90);

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('interview-recordings')
          .getPublicUrl(data.path);

        onProgress?.(100);
        return publicUrl;

      } catch (uploadError: any) {
        console.error(`Upload attempt ${attempt} failed:`, uploadError);
        
        if (attempt === retryCount) {
          if (fallbackToOffline) {
            console.log('All upload attempts failed, falling back to offline storage');
            return await fallbackToOfflineStorage(videoBlob, fileName, quality);
          }
          throw uploadError;
        }
        
        // Wait before retry (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }

    throw new Error('Upload failed after all retries');

  } catch (error: any) {
    console.error('Video upload error:', error);
    
    if (fallbackToOffline) {
      return await fallbackToOfflineStorage(videoBlob, fileName, quality);
    }
    
    throw new Error(`Failed to upload video: ${error.message}`);
  }
};

const fallbackToOfflineStorage = async (
  blob: Blob, 
  fileName: string, 
  quality: string
): Promise<string> => {
  try {
    const videoInfo = await videoProcessor.getVideoInfo(blob);
    
    const recording = {
      id: fileName,
      blob,
      questionId: fileName.split('-')[1] || 'unknown',
      timestamp: Date.now(),
      metadata: {
        duration: videoInfo.duration,
        size: blob.size,
        quality,
        uploaded: false
      }
    };

    await offlineStorage.saveRecording(recording);
    
    // Return a local URL for offline access
    return `offline://${fileName}`;
  } catch (error) {
    console.error('Offline storage failed:', error);
    throw new Error('Failed to save video offline');
  }
};

export const syncOfflineRecordings = async (): Promise<void> => {
  if (!navigator.onLine || !isSupabaseConfigured()) {
    return;
  }

  try {
    await offlineStorage.syncWithCloud();
  } catch (error) {
    console.error('Sync failed:', error);
  }
};

export const getStorageStats = async (): Promise<{
  online: boolean;
  configured: boolean;
  offlineUsage: { used: number; quota: number };
  offlineRecordings: number;
}> => {
  const offlineUsage = await offlineStorage.getStorageUsage();
  const offlineRecordings = await offlineStorage.getAllRecordings();

  return {
    online: navigator.onLine,
    configured: isSupabaseConfigured(),
    offlineUsage,
    offlineRecordings: offlineRecordings.length
  };
};

// Auto-sync when coming back online
window.addEventListener('online', () => {
  console.log('Network restored, attempting to sync offline recordings...');
  syncOfflineRecordings();
});