import axios from 'axios';
import { JobListing, TrendingSkill, MarketInsight, SalaryPrediction, SkillGapAnalysis } from '../types/jobs';

const RAPID_API_KEY = import.meta.env.VITE_RAPID_API_KEY;
const SERPER_API_KEY = import.meta.env.VITE_SERPER_API_KEY;

class JobDataEngine {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private readonly CACHE_TTL = {
    jobs: 30 * 60 * 1000, // 30 minutes
    trends: 60 * 60 * 1000, // 1 hour
    insights: 15 * 60 * 1000, // 15 minutes
    salary: 24 * 60 * 60 * 1000, // 24 hours
  };

  private getCachedData<T>(key: string): T | null {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return cached.data;
    }
    this.cache.delete(key);
    return null;
  }

  private setCachedData(key: string, data: any, ttl: number): void {
    this.cache.set(key, { data, timestamp: Date.now(), ttl });
  }

  async searchJobs(params: {
    query?: string;
    location?: string;
    remote?: boolean;
    salaryMin?: number;
    experienceLevel?: string;
    limit?: number;
  }): Promise<JobListing[]> {
    const cacheKey = `jobs:${JSON.stringify(params)}`;
    const cached = this.getCachedData<JobListing[]>(cacheKey);
    if (cached) return cached;

    try {
      // Try multiple sources in parallel
      const [linkedinJobs, indeedJobs, glassdoorJobs] = await Promise.allSettled([
        this.fetchLinkedInJobs(params),
        this.fetchIndeedJobs(params),
        this.fetchGlassdoorJobs(params),
      ]);

      const allJobs: JobListing[] = [];
      
      if (linkedinJobs.status === 'fulfilled') allJobs.push(...linkedinJobs.value);
      if (indeedJobs.status === 'fulfilled') allJobs.push(...indeedJobs.value);
      if (glassdoorJobs.status === 'fulfilled') allJobs.push(...glassdoorJobs.value);

      // Deduplicate and sort by relevance
      const uniqueJobs = this.deduplicateJobs(allJobs);
      const sortedJobs = this.sortJobsByRelevance(uniqueJobs, params.query);

      this.setCachedData(cacheKey, sortedJobs, this.CACHE_TTL.jobs);
      return sortedJobs;
    } catch (error) {
      console.error('Job search error:', error);
      return this.getMockJobs(params);
    }
  }

  private async fetchLinkedInJobs(params: any): Promise<JobListing[]> {
    if (!RAPID_API_KEY) throw new Error('LinkedIn API not configured');

    const response = await axios.get('https://linkedin-jobs-search.p.rapidapi.com/jobs', {
      headers: {
        'X-RapidAPI-Key': RAPID_API_KEY,
        'X-RapidAPI-Host': 'linkedin-jobs-search.p.rapidapi.com'
      },
      params: {
        keywords: params.query || 'software engineer',
        location: params.location || 'United States',
        dateSincePosted: 'week',
        sort: 'mostRelevant'
      }
    });

    return response.data.jobs?.map((job: any) => ({
      id: `linkedin-${job.id}`,
      title: job.title,
      company: job.company,
      companyLogo: job.companyLogo,
      location: job.location,
      remote: job.location?.toLowerCase().includes('remote') || false,
      hybrid: job.location?.toLowerCase().includes('hybrid') || false,
      salary: this.parseSalary(job.salary),
      description: job.description,
      requirements: this.extractRequirements(job.description),
      benefits: this.extractBenefits(job.description),
      postedDate: job.postedDate,
      source: 'linkedin' as const,
      sourceUrl: job.url,
      trending: this.isTrending(job.title),
      verified: true,
      tags: this.extractTags(job.description),
      skillsRequired: this.extractSkills(job.description),
      experienceLevel: this.determineExperienceLevel(job.title, job.description),
      department: this.determineDepartment(job.title),
      employmentType: this.determineEmploymentType(job.description),
      matchScore: this.calculateMatchScore(job, params)
    })) || [];
  }

  private async fetchIndeedJobs(params: any): Promise<JobListing[]> {
    // Mock Indeed integration - replace with actual API
    return this.getMockJobs(params, 'indeed').slice(0, 10);
  }

  private async fetchGlassdoorJobs(params: any): Promise<JobListing[]> {
    // Mock Glassdoor integration - replace with actual API
    return this.getMockJobs(params, 'glassdoor').slice(0, 5);
  }

  async getTrendingSkills(timeframe: '7d' | '30d' | '90d' = '30d'): Promise<TrendingSkill[]> {
    const cacheKey = `trends:skills:${timeframe}`;
    const cached = this.getCachedData<TrendingSkill[]>(cacheKey);
    if (cached) return cached;

    try {
      // Use Serper API to search for trending skills
      const response = await axios.post('https://google.serper.dev/search', {
        q: `trending programming skills ${new Date().getFullYear()} jobs demand`,
        num: 20
      }, {
        headers: {
          'X-API-KEY': SERPER_API_KEY,
          'Content-Type': 'application/json'
        }
      });

      const trends = this.analyzeTrendingSkills(response.data);
      this.setCachedData(cacheKey, trends, this.CACHE_TTL.trends);
      return trends;
    } catch (error) {
      console.error('Trending skills error:', error);
      return this.getMockTrendingSkills();
    }
  }

  async getMarketInsights(): Promise<MarketInsight[]> {
    const cacheKey = 'insights:market';
    const cached = this.getCachedData<MarketInsight[]>(cacheKey);
    if (cached) return cached;

    try {
      const [techNews, layoffNews, hiringNews] = await Promise.allSettled([
        this.fetchTechNews(),
        this.fetchLayoffNews(),
        this.fetchHiringNews()
      ]);

      const insights: MarketInsight[] = [];
      
      if (techNews.status === 'fulfilled') insights.push(...techNews.value);
      if (layoffNews.status === 'fulfilled') insights.push(...layoffNews.value);
      if (hiringNews.status === 'fulfilled') insights.push(...hiringNews.value);

      const sortedInsights = insights
        .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
        .slice(0, 20);

      this.setCachedData(cacheKey, sortedInsights, this.CACHE_TTL.insights);
      return sortedInsights;
    } catch (error) {
      console.error('Market insights error:', error);
      return this.getMockMarketInsights();
    }
  }

  async predictSalary(params: {
    role: string;
    location: string;
    experience: number;
    skills: string[];
  }): Promise<SalaryPrediction> {
    const cacheKey = `salary:${JSON.stringify(params)}`;
    const cached = this.getCachedData<SalaryPrediction>(cacheKey);
    if (cached) return cached;

    try {
      // Use multiple data sources for salary prediction
      const [glassdoorData, payScaleData, linkedinData] = await Promise.allSettled([
        this.fetchGlassdoorSalary(params),
        this.fetchPayScaleSalary(params),
        this.fetchLinkedInSalary(params)
      ]);

      const prediction = this.calculateSalaryPrediction(params, {
        glassdoor: glassdoorData.status === 'fulfilled' ? glassdoorData.value : null,
        payScale: payScaleData.status === 'fulfilled' ? payScaleData.value : null,
        linkedin: linkedinData.status === 'fulfilled' ? linkedinData.value : null
      });

      this.setCachedData(cacheKey, prediction, this.CACHE_TTL.salary);
      return prediction;
    } catch (error) {
      console.error('Salary prediction error:', error);
      return this.getMockSalaryPrediction(params);
    }
  }

  async analyzeSkillGap(userSkills: string[], targetRole: string): Promise<SkillGapAnalysis> {
    try {
      // Fetch job requirements for target role
      const jobs = await this.searchJobs({ query: targetRole, limit: 50 });
      const requiredSkills = this.aggregateRequiredSkills(jobs);
      
      const missingSkills = requiredSkills
        .filter(skill => !userSkills.some(userSkill => 
          userSkill.toLowerCase().includes(skill.name.toLowerCase())
        ))
        .map(skill => ({
          skill: skill.name,
          importance: skill.frequency / jobs.length,
          timeToLearn: this.estimateLearningTime(skill.name),
          resources: this.findLearningResources(skill.name)
        }));

      const strengthSkills = userSkills.filter(userSkill =>
        requiredSkills.some(reqSkill =>
          reqSkill.name.toLowerCase().includes(userSkill.toLowerCase())
        )
      );

      const overallReadiness = Math.max(0, Math.min(100, 
        (strengthSkills.length / (strengthSkills.length + missingSkills.length)) * 100
      ));

      return {
        userSkills,
        targetRole,
        missingSkills,
        strengthSkills,
        improvementAreas: missingSkills.slice(0, 5).map(skill => skill.skill),
        overallReadiness
      };
    } catch (error) {
      console.error('Skill gap analysis error:', error);
      return this.getMockSkillGapAnalysis(userSkills, targetRole);
    }
  }

  // Helper methods
  private deduplicateJobs(jobs: JobListing[]): JobListing[] {
    const seen = new Set<string>();
    return jobs.filter(job => {
      const key = `${job.title}-${job.company}-${job.location}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private sortJobsByRelevance(jobs: JobListing[], query?: string): JobListing[] {
    if (!query) return jobs.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
    
    return jobs.sort((a, b) => {
      const aRelevance = this.calculateRelevanceScore(a, query);
      const bRelevance = this.calculateRelevanceScore(b, query);
      return bRelevance - aRelevance;
    });
  }

  private calculateRelevanceScore(job: JobListing, query: string): number {
    const queryLower = query.toLowerCase();
    let score = 0;
    
    if (job.title.toLowerCase().includes(queryLower)) score += 10;
    if (job.description.toLowerCase().includes(queryLower)) score += 5;
    if (job.skillsRequired.some(skill => skill.toLowerCase().includes(queryLower))) score += 8;
    if (job.trending) score += 3;
    if (job.verified) score += 2;
    
    return score + (job.matchScore || 0);
  }

  // Mock data methods for development
  private getMockJobs(params: any, source: string = 'mock'): JobListing[] {
    const mockJobs: JobListing[] = [
      {
        id: `${source}-1`,
        title: 'Senior Software Engineer',
        company: 'TechCorp Inc.',
        companyLogo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=64&h=64&fit=crop&crop=center',
        location: 'San Francisco, CA',
        remote: true,
        hybrid: false,
        salary: { min: 150000, max: 200000, currency: 'USD', period: 'yearly' },
        description: 'We are looking for a senior software engineer to join our team...',
        requirements: ['5+ years experience', 'React', 'Node.js', 'TypeScript'],
        benefits: ['Health insurance', 'Remote work', '401k matching'],
        postedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        source: source as any,
        sourceUrl: 'https://example.com/job/1',
        trending: true,
        verified: true,
        tags: ['tech', 'remote', 'senior'],
        skillsRequired: ['React', 'Node.js', 'TypeScript', 'AWS'],
        experienceLevel: 'senior',
        department: 'Engineering',
        employmentType: 'full-time',
        applicationStatus: 'not-applied',
        matchScore: 95
      },
      {
        id: `${source}-2`,
        title: 'Product Manager',
        company: 'StartupXYZ',
        location: 'New York, NY',
        remote: false,
        hybrid: true,
        salary: { min: 120000, max: 160000, currency: 'USD', period: 'yearly' },
        description: 'Join our product team to drive innovation...',
        requirements: ['3+ years PM experience', 'Agile', 'Data analysis'],
        benefits: ['Equity', 'Flexible hours', 'Learning budget'],
        postedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        source: source as any,
        sourceUrl: 'https://example.com/job/2',
        trending: false,
        verified: true,
        tags: ['product', 'startup', 'hybrid'],
        skillsRequired: ['Product Management', 'Analytics', 'Agile'],
        experienceLevel: 'mid',
        department: 'Product',
        employmentType: 'full-time',
        applicationStatus: 'not-applied',
        matchScore: 78
      }
    ];

    return mockJobs.filter(job => {
      if (params.query && !job.title.toLowerCase().includes(params.query.toLowerCase())) return false;
      if (params.location && !job.location.toLowerCase().includes(params.location.toLowerCase())) return false;
      if (params.remote && !job.remote) return false;
      return true;
    });
  }

  private getMockTrendingSkills(): TrendingSkill[] {
    return [
      { name: 'React', demand: 25, averageSalary: 95000, jobCount: 1250, growth: 'rising', category: 'Frontend' },
      { name: 'Python', demand: 30, averageSalary: 105000, jobCount: 2100, growth: 'rising', category: 'Backend' },
      { name: 'AWS', demand: 40, averageSalary: 120000, jobCount: 1800, growth: 'rising', category: 'Cloud' },
      { name: 'TypeScript', demand: 35, averageSalary: 98000, jobCount: 950, growth: 'rising', category: 'Frontend' },
      { name: 'Kubernetes', demand: 45, averageSalary: 130000, jobCount: 650, growth: 'rising', category: 'DevOps' }
    ];
  }

  private getMockMarketInsights(): MarketInsight[] {
    return [
      {
        id: '1',
        title: 'Tech Giants Increase AI Hiring by 40%',
        summary: 'Major technology companies are ramping up AI talent acquisition...',
        impact: 'high',
        category: 'hiring',
        companies: ['Google', 'Microsoft', 'Amazon'],
        affectedRoles: ['ML Engineer', 'Data Scientist', 'AI Researcher'],
        publishedAt: new Date().toISOString(),
        source: 'TechCrunch',
        sourceUrl: 'https://techcrunch.com/ai-hiring-surge'
      }
    ];
  }

  private getMockSalaryPrediction(params: any): SalaryPrediction {
    const basesalary = 85000;
    const experienceMultiplier = 1 + (params.experience * 0.1);
    const locationMultiplier = params.location.includes('San Francisco') ? 1.4 : 1.0;
    
    const median = Math.round(basesalary * experienceMultiplier * locationMultiplier);
    
    return {
      role: params.role,
      location: params.location,
      experience: params.experience,
      predicted: {
        min: Math.round(median * 0.8),
        max: Math.round(median * 1.3),
        median,
        confidence: 85
      },
      factors: [
        { name: 'Experience Level', impact: 25, description: `${params.experience} years experience` },
        { name: 'Location', impact: 20, description: `${params.location} market rates` },
        { name: 'Skills Match', impact: 15, description: 'Relevant technical skills' }
      ],
      marketData: {
        totalJobs: 1250,
        averagePosted: 45,
        competitionLevel: 'medium'
      }
    };
  }

  private getMockSkillGapAnalysis(userSkills: string[], targetRole: string): SkillGapAnalysis {
    return {
      userSkills,
      targetRole,
      missingSkills: [
        {
          skill: 'React',
          importance: 0.8,
          timeToLearn: '2-3 months',
          resources: [
            { name: 'React Official Tutorial', type: 'course', url: 'https://react.dev', cost: 0, duration: '2 weeks' }
          ]
        }
      ],
      strengthSkills: userSkills.slice(0, 3),
      improvementAreas: ['React', 'TypeScript', 'AWS'],
      overallReadiness: 65
    };
  }

  // Additional helper methods would be implemented here
  private parseSalary(salaryText: string): any { return { min: 80000, max: 120000, currency: 'USD', period: 'yearly' }; }
  private extractRequirements(description: string): string[] { return ['Experience required']; }
  private extractBenefits(description: string): string[] { return ['Health insurance']; }
  private isTrending(title: string): boolean { return Math.random() > 0.7; }
  private extractTags(description: string): string[] { return ['tech']; }
  private extractSkills(description: string): string[] { return ['JavaScript']; }
  private determineExperienceLevel(title: string, description: string): any { return 'mid'; }
  private determineDepartment(title: string): string { return 'Engineering'; }
  private determineEmploymentType(description: string): any { return 'full-time'; }
  private calculateMatchScore(job: any, params: any): number { return Math.floor(Math.random() * 40) + 60; }
  private analyzeTrendingSkills(data: any): TrendingSkill[] { return this.getMockTrendingSkills(); }
  private fetchTechNews(): Promise<MarketInsight[]> { return Promise.resolve(this.getMockMarketInsights()); }
  private fetchLayoffNews(): Promise<MarketInsight[]> { return Promise.resolve([]); }
  private fetchHiringNews(): Promise<MarketInsight[]> { return Promise.resolve([]); }
  private fetchGlassdoorSalary(params: any): Promise<any> { return Promise.resolve({}); }
  private fetchPayScaleSalary(params: any): Promise<any> { return Promise.resolve({}); }
  private fetchLinkedInSalary(params: any): Promise<any> { return Promise.resolve({}); }
  private calculateSalaryPrediction(params: any, data: any): SalaryPrediction { return this.getMockSalaryPrediction(params); }
  private aggregateRequiredSkills(jobs: JobListing[]): any[] { return []; }
  private estimateLearningTime(skill: string): string { return '2-3 months'; }
  private findLearningResources(skill: string): any[] { return []; }
}

export const jobDataEngine = new JobDataEngine();