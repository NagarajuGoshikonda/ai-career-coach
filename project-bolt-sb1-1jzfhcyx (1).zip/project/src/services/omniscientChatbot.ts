import axios from 'axios';

interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type: 'text' | 'voice' | 'file';
  source?: 'chatgpt' | 'deepseek' | 'google' | 'human' | 'knowledge_base';
  confidence?: number;
  citations?: Citation[];
  verified?: boolean;
  rating?: number;
}

interface Citation {
  title: string;
  url: string;
  snippet: string;
  source: string;
}

interface HumanEscalation {
  id: string;
  query: string;
  context: string;
  urgency: 'low' | 'medium' | 'high';
  category: 'technical' | 'career' | 'interview' | 'salary';
  status: 'pending' | 'assigned' | 'resolved';
  assignedTo?: string;
  discordThreadId?: string;
}

class OmniscientChatbot {
  private readonly OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;
  private readonly DEEPSEEK_API_KEY = import.meta.env.VITE_DEEPSEEK_API_KEY;
  private readonly SERPER_API_KEY = import.meta.env.VITE_SERPER_API_KEY;
  private readonly DISCORD_WEBHOOK = import.meta.env.VITE_DISCORD_WEBHOOK;
  
  private knowledgeBase = new Map<string, any>();
  private conversationHistory: ChatMessage[] = [];

  async processQuery(
    query: string, 
    context: {
      userProfile?: any;
      conversationHistory?: ChatMessage[];
      requireVerification?: boolean;
    } = {}
  ): Promise<ChatMessage> {
    try {
      // 1. Check knowledge base first
      const cachedAnswer = this.searchKnowledgeBase(query);
      if (cachedAnswer && !context.requireVerification) {
        return this.createBotMessage(cachedAnswer.content, 'knowledge_base', cachedAnswer.confidence);
      }

      // 2. Determine best AI model based on query type
      const queryType = this.categorizeQuery(query);
      let response: ChatMessage;

      switch (queryType) {
        case 'technical':
          response = await this.queryDeepSeek(query, context);
          break;
        case 'general':
        case 'career':
          response = await this.queryChatGPT(query, context);
          break;
        case 'current_events':
        case 'market_data':
          response = await this.queryWithGoogleVerification(query, context);
          break;
        default:
          response = await this.queryChatGPT(query, context);
      }

      // 3. Add to knowledge base if confidence is high
      if (response.confidence && response.confidence > 0.8) {
        this.updateKnowledgeBase(query, response);
      }

      // 4. Check if human escalation is needed
      if (response.confidence && response.confidence < 0.6) {
        await this.escalateToHuman(query, context, response);
      }

      return response;
    } catch (error) {
      console.error('Chatbot processing error:', error);
      return this.createErrorResponse(query);
    }
  }

  private async queryChatGPT(query: string, context: any): Promise<ChatMessage> {
    if (!this.OPENAI_API_KEY) {
      return this.createMockResponse(query, 'chatgpt');
    }

    try {
      const systemPrompt = this.buildSystemPrompt(context);
      
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          ...this.formatConversationHistory(context.conversationHistory || []),
          { role: 'user', content: query }
        ],
        temperature: 0.7,
        max_tokens: 1000
      }, {
        headers: {
          'Authorization': `Bearer ${this.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      const content = response.data.choices[0].message.content;
      const confidence = this.calculateConfidence(content, 'chatgpt');

      return this.createBotMessage(content, 'chatgpt', confidence);
    } catch (error) {
      console.error('ChatGPT error:', error);
      return this.createMockResponse(query, 'chatgpt');
    }
  }

  private async queryDeepSeek(query: string, context: any): Promise<ChatMessage> {
    if (!this.DEEPSEEK_API_KEY) {
      return this.createMockResponse(query, 'deepseek');
    }

    try {
      const response = await axios.post('https://api.deepseek.com/v1/chat/completions', {
        model: 'deepseek-coder',
        messages: [
          { role: 'system', content: 'You are a technical interview expert specializing in coding questions and system design.' },
          { role: 'user', content: query }
        ],
        temperature: 0.3,
        max_tokens: 1500
      }, {
        headers: {
          'Authorization': `Bearer ${this.DEEPSEEK_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      const content = response.data.choices[0].message.content;
      const confidence = this.calculateConfidence(content, 'deepseek');

      return this.createBotMessage(content, 'deepseek', confidence);
    } catch (error) {
      console.error('DeepSeek error:', error);
      return this.createMockResponse(query, 'deepseek');
    }
  }

  private async queryWithGoogleVerification(query: string, context: any): Promise<ChatMessage> {
    try {
      // First get AI response
      const aiResponse = await this.queryChatGPT(query, context);
      
      // Then verify with Google search
      const googleResults = await this.searchGoogle(query);
      const citations = this.extractCitations(googleResults);
      
      // Combine and verify information
      const verifiedContent = await this.verifyWithSources(aiResponse.content, citations);
      
      return {
        ...aiResponse,
        content: verifiedContent,
        citations,
        verified: true,
        confidence: Math.min((aiResponse.confidence || 0.7) + 0.2, 1.0)
      };
    } catch (error) {
      console.error('Google verification error:', error);
      return this.queryChatGPT(query, context);
    }
  }

  private async searchGoogle(query: string): Promise<any> {
    if (!this.SERPER_API_KEY) {
      return { organic: [] };
    }

    try {
      const response = await axios.post('https://google.serper.dev/search', {
        q: query,
        num: 5
      }, {
        headers: {
          'X-API-KEY': this.SERPER_API_KEY,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      console.error('Google search error:', error);
      return { organic: [] };
    }
  }

  private async escalateToHuman(query: string, context: any, aiResponse: ChatMessage): Promise<void> {
    if (!this.DISCORD_WEBHOOK) return;

    try {
      const escalation: HumanEscalation = {
        id: `esc-${Date.now()}`,
        query,
        context: JSON.stringify(context),
        urgency: this.determineUrgency(query, aiResponse),
        category: this.categorizeQuery(query) as any,
        status: 'pending'
      };

      await axios.post(this.DISCORD_WEBHOOK, {
        embeds: [{
          title: '🚨 Human Escalation Required',
          description: `**Query:** ${query}\n**AI Confidence:** ${(aiResponse.confidence || 0) * 100}%`,
          color: escalation.urgency === 'high' ? 0xff0000 : escalation.urgency === 'medium' ? 0xffa500 : 0xffff00,
          fields: [
            { name: 'Category', value: escalation.category, inline: true },
            { name: 'Urgency', value: escalation.urgency, inline: true },
            { name: 'AI Response', value: aiResponse.content.substring(0, 500) + '...', inline: false }
          ],
          timestamp: new Date().toISOString()
        }]
      });
    } catch (error) {
      console.error('Discord escalation error:', error);
    }
  }

  async rateResponse(messageId: string, rating: number, feedback?: string): Promise<void> {
    // Store rating in knowledge base for learning
    const message = this.conversationHistory.find(m => m.id === messageId);
    if (message) {
      message.rating = rating;
      
      // Update knowledge base confidence based on rating
      if (rating >= 4) {
        this.updateKnowledgeBase(message.content, message, 0.9);
      } else if (rating <= 2) {
        this.updateKnowledgeBase(message.content, message, 0.3);
      }
    }
  }

  async verifyWithCommunity(query: string): Promise<{ verified: boolean; sources: Citation[] }> {
    // Simulate community verification
    const mockSources: Citation[] = [
      {
        title: 'Stack Overflow Discussion',
        url: 'https://stackoverflow.com/questions/example',
        snippet: 'Community consensus on this topic...',
        source: 'Stack Overflow'
      }
    ];

    return {
      verified: Math.random() > 0.3,
      sources: mockSources
    };
  }

  // Helper methods
  private categorizeQuery(query: string): string {
    const queryLower = query.toLowerCase();
    
    if (queryLower.includes('code') || queryLower.includes('algorithm') || queryLower.includes('programming')) {
      return 'technical';
    }
    if (queryLower.includes('salary') || queryLower.includes('market') || queryLower.includes('trend')) {
      return 'market_data';
    }
    if (queryLower.includes('career') || queryLower.includes('interview') || queryLower.includes('job')) {
      return 'career';
    }
    if (queryLower.includes('recent') || queryLower.includes('latest') || queryLower.includes('news')) {
      return 'current_events';
    }
    
    return 'general';
  }

  private searchKnowledgeBase(query: string): any {
    // Simple keyword matching - in production, use vector similarity
    for (const [key, value] of this.knowledgeBase.entries()) {
      if (query.toLowerCase().includes(key.toLowerCase()) || 
          key.toLowerCase().includes(query.toLowerCase())) {
        return value;
      }
    }
    return null;
  }

  private updateKnowledgeBase(query: string, response: ChatMessage, confidence?: number): void {
    const key = query.toLowerCase().trim();
    this.knowledgeBase.set(key, {
      content: response.content,
      confidence: confidence || response.confidence || 0.7,
      timestamp: Date.now(),
      source: response.source
    });
  }

  private buildSystemPrompt(context: any): string {
    return `You are an expert AI career coach with deep knowledge of:
- Interview preparation and techniques
- Career development and progression
- Industry trends and market insights
- Technical skills and certifications
- Salary negotiation and job search strategies

User context: ${JSON.stringify(context.userProfile || {})}

Provide helpful, accurate, and actionable advice. If you're uncertain about current market data or recent trends, indicate that the information should be verified with recent sources.`;
  }

  private formatConversationHistory(history: ChatMessage[]): any[] {
    return history.slice(-10).map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'assistant',
      content: msg.content
    }));
  }

  private calculateConfidence(content: string, source: string): number {
    let confidence = 0.7; // Base confidence
    
    // Adjust based on content characteristics
    if (content.includes('I\'m not sure') || content.includes('uncertain')) confidence -= 0.3;
    if (content.includes('definitely') || content.includes('certainly')) confidence += 0.1;
    if (content.length > 500) confidence += 0.1; // Detailed responses
    
    // Adjust based on source
    if (source === 'deepseek') confidence += 0.1; // Technical expertise
    if (source === 'google') confidence += 0.2; // Verified information
    
    return Math.max(0.1, Math.min(1.0, confidence));
  }

  private extractCitations(googleResults: any): Citation[] {
    return (googleResults.organic || []).slice(0, 3).map((result: any) => ({
      title: result.title,
      url: result.link,
      snippet: result.snippet,
      source: new URL(result.link).hostname
    }));
  }

  private async verifyWithSources(content: string, citations: Citation[]): Promise<string> {
    if (citations.length === 0) return content;
    
    const footnotes = citations.map((citation, index) => 
      `[${index + 1}] ${citation.title} - ${citation.source}`
    ).join('\n');
    
    return `${content}\n\n**Sources:**\n${footnotes}`;
  }

  private determineUrgency(query: string, response: ChatMessage): 'low' | 'medium' | 'high' {
    if (query.toLowerCase().includes('urgent') || query.toLowerCase().includes('asap')) return 'high';
    if (response.confidence && response.confidence < 0.4) return 'high';
    if (query.toLowerCase().includes('interview tomorrow')) return 'high';
    if (response.confidence && response.confidence < 0.6) return 'medium';
    return 'low';
  }

  private createBotMessage(content: string, source: any, confidence?: number): ChatMessage {
    return {
      id: `bot-${Date.now()}`,
      content,
      sender: 'bot',
      timestamp: new Date(),
      type: 'text',
      source,
      confidence
    };
  }

  private createMockResponse(query: string, source: any): ChatMessage {
    const mockResponses = {
      technical: "Based on common interview patterns, here's a comprehensive approach to this technical question...",
      career: "For career advancement, I recommend focusing on these key areas...",
      general: "Here's what I can tell you based on current industry practices..."
    };
    
    const category = this.categorizeQuery(query);
    const content = mockResponses[category as keyof typeof mockResponses] || mockResponses.general;
    
    return this.createBotMessage(content, source, 0.7);
  }

  private createErrorResponse(query: string): ChatMessage {
    return this.createBotMessage(
      "I apologize, but I'm experiencing some technical difficulties. Let me try a different approach to help you with your question.",
      'error',
      0.3
    );
  }
}

export const omniscientChatbot = new OmniscientChatbot();