interface ElevenLabsVoiceSettings {
  stability: number;
  similarity_boost: number;
  style: number;
  use_speaker_boost: boolean;
}

const ELEVENLABS_API_KEY = import.meta.env.VITE_ELEVENLABS_API_KEY;
const ELEVENLABS_BASE_URL = 'https://api.elevenlabs.io/v1';
const DEFAULT_VOICE_ID = 'pNInz6obpgDQGcFmaJgB'; // Adam voice

export const generateVoiceFeedback = async (
  analysisResult: any,
  voiceId: string = DEFAULT_VOICE_ID
): Promise<string> => {
  try {
    const feedbackText = generateFeedbackText(analysisResult);
    
    const response = await fetch(`${ELEVENLABS_BASE_URL}/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': ELEVENLABS_API_KEY,
      },
      body: JSON.stringify({
        text: feedbackText,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
          style: 0.0,
          use_speaker_boost: true,
        } as ElevenLabsVoiceSettings,
      }),
    });

    if (!response.ok) {
      throw new Error(`ElevenLabs API error: ${response.status}`);
    }

    const audioBlob = await response.blob();
    return URL.createObjectURL(audioBlob);
  } catch (error) {
    console.error('ElevenLabs error:', error);
    
    // Return mock audio URL for development
    if (import.meta.env.DEV) {
      return getMockAudioFeedback(analysisResult);
    }
    
    throw new Error('Failed to generate voice feedback');
  }
};

const generateFeedbackText = (analysis: any): string => {
  const parts = [];
  
  parts.push(`Great job completing your interview practice! Here's your feedback.`);
  
  if (analysis.overall_score) {
    parts.push(`Your overall score is ${analysis.overall_score} out of 100.`);
  }
  
  if (analysis.filler_words !== undefined) {
    if (analysis.filler_words <= 3) {
      parts.push(`Excellent! You only used ${analysis.filler_words} filler words. Keep it up!`);
    } else if (analysis.filler_words <= 7) {
      parts.push(`You used ${analysis.filler_words} filler words. Try pausing instead of saying um or uh.`);
    } else {
      parts.push(`You used ${analysis.filler_words} filler words. Focus on reducing these by taking brief pauses to collect your thoughts.`);
    }
  }
  
  if (analysis.eye_contact_percentage !== undefined) {
    if (analysis.eye_contact_percentage >= 80) {
      parts.push(`Great eye contact! You maintained ${analysis.eye_contact_percentage}% eye contact with the camera.`);
    } else if (analysis.eye_contact_percentage >= 60) {
      parts.push(`Your eye contact scored ${analysis.eye_contact_percentage}%. Try to look directly at the camera more consistently.`);
    } else {
      parts.push(`Your eye contact needs improvement at ${analysis.eye_contact_percentage}%. Remember to look directly at the camera as if it's the interviewer.`);
    }
  }
  
  if (analysis.confidence_score !== undefined) {
    if (analysis.confidence_score >= 85) {
      parts.push(`You spoke with great confidence! Your confidence score was ${analysis.confidence_score}%.`);
    } else if (analysis.confidence_score >= 70) {
      parts.push(`Good confidence level at ${analysis.confidence_score}%. Try speaking with even more conviction.`);
    } else {
      parts.push(`Work on speaking more confidently. Your confidence score was ${analysis.confidence_score}%. Practice will help build your confidence.`);
    }
  }
  
  parts.push(`Keep practicing to improve your interview skills. You're doing great!`);
  
  return parts.join(' ');
};

const getMockAudioFeedback = (analysis: any): string => {
  // Return a data URL for a short beep sound as mock audio
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  
  oscillator.frequency.value = 800;
  gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
  
  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 0.5);
  
  // For development, return a placeholder
  return 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT';
};