import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

// Check if Supabase is properly configured
const isSupabaseConfigured = () => {
  return supabaseUrl !== 'https://your-project.supabase.co' && 
         supabaseAnonKey !== 'your-anon-key' &&
         supabaseUrl.includes('supabase.co');
};

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const uploadVideoToSupabase = async (videoBlob: Blob, fileName: string): Promise<string> => {
  // Check if Supabase is configured
  if (!isSupabaseConfigured()) {
    throw new Error(
      'Supabase is not configured. Please set up your VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables in the .env file. ' +
      'You can find these values in your Supabase project settings under API.'
    );
  }

  try {
    // First, check if the bucket exists and is accessible
    const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets();
    
    if (bucketsError) {
      console.error('Error accessing Supabase storage:', bucketsError);
      throw new Error('Unable to access Supabase storage. Please check your configuration and permissions.');
    }

    // Check if the interview-recordings bucket exists
    const bucketExists = buckets?.some(bucket => bucket.name === 'interview-recordings');
    
    if (!bucketExists) {
      throw new Error(
        'The "interview-recordings" storage bucket does not exist. ' +
        'Please create this bucket in your Supabase project dashboard under Storage.'
      );
    }

    const { data, error } = await supabase.storage
      .from('interview-recordings')
      .upload(fileName, videoBlob, {
        contentType: 'video/mp4',
        upsert: false
      });

    if (error) {
      console.error('Supabase upload error:', error);
      throw new Error(`Failed to upload video: ${error.message}`);
    }

    const { data: { publicUrl } } = supabase.storage
      .from('interview-recordings')
      .getPublicUrl(data.path);

    return publicUrl;
  } catch (error: any) {
    console.error('Error uploading video:', error);
    
    // Re-throw with more specific error message if it's already a custom error
    if (error.message.includes('Supabase is not configured') || 
        error.message.includes('interview-recordings') ||
        error.message.includes('Unable to access Supabase storage')) {
      throw error;
    }
    
    throw new Error('Failed to upload video to storage. Please check your internet connection and Supabase configuration.');
  }
};