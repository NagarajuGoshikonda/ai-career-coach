interface OfflineRecording {
  id: string;
  blob: Blob;
  questionId: string;
  timestamp: number;
  metadata: {
    duration: number;
    size: number;
    quality: string;
  };
}

class OfflineStorageService {
  private dbName = 'AICareerCoachDB';
  private version = 1;
  private storeName = 'recordings';

  async openDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('timestamp', 'timestamp', { unique: false });
          store.createIndex('questionId', 'questionId', { unique: false });
        }
      };
    });
  }

  async saveRecording(recording: OfflineRecording): Promise<void> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.add(recording);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getRecording(id: string): Promise<OfflineRecording | null> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readonly');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllRecordings(): Promise<OfflineRecording[]> {
    const db = await this.openDB();
    const transaction =  db.transaction([this.storeName], 'readonly');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async deleteRecording(id: string): Promise<void> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clearAllRecordings(): Promise<void> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getStorageUsage(): Promise<{ used: number; quota: number }> {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      return {
        used: estimate.usage || 0,
        quota: estimate.quota || 0
      };
    }
    
    return { used: 0, quota: 0 };
  }

  async syncWithCloud(): Promise<void> {
    const recordings = await this.getAllRecordings();
    const pendingUploads = recordings.filter(r => !r.metadata.uploaded);
    
    for (const recording of pendingUploads) {
      try {
        // Attempt to upload to Supabase
        const { uploadVideoToSupabase } = await import('./supabase');
        const fileName = `offline-sync-${recording.id}.mp4`;
        await uploadVideoToSupabase(recording.blob, fileName);
        
        // Mark as uploaded
        recording.metadata.uploaded = true;
        await this.updateRecording(recording);
        
        console.log(`Successfully synced recording ${recording.id}`);
      } catch (error) {
        console.error(`Failed to sync recording ${recording.id}:`, error);
      }
    }
  }

  private async updateRecording(recording: OfflineRecording): Promise<void> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    
    return new Promise((resolve, reject) => {
      const request = store.put(recording);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
}

export const offlineStorage = new OfflineStorageService();