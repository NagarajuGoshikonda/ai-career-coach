import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AppState {
  theme: 'light' | 'dark';
  isOfflineMode: boolean;
  recordingQuality: 'low' | 'medium' | 'high';
  voiceEnabled: boolean;
  notifications: boolean;
  cacheSize: number;
  
  // Actions
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  setOfflineMode: (offline: boolean) => void;
  setRecordingQuality: (quality: 'low' | 'medium' | 'high') => void;
  setVoiceEnabled: (enabled: boolean) => void;
  setNotifications: (enabled: boolean) => void;
  clearCache: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: 'dark',
      isOfflineMode: false,
      recordingQuality: 'high',
      voiceEnabled: true,
      notifications: true,
      cacheSize: 0,
      
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set((state) => ({ 
        theme: state.theme === 'light' ? 'dark' : 'light' 
      })),
      setOfflineMode: (isOfflineMode) => set({ isOfflineMode }),
      setRecordingQuality: (recordingQuality) => set({ recordingQuality }),
      setVoiceEnabled: (voiceEnabled) => set({ voiceEnabled }),
      setNotifications: (notifications) => set({ notifications }),
      clearCache: () => set({ cacheSize: 0 }),
    }),
    {
      name: 'ai-career-coach-settings',
    }
  )
);