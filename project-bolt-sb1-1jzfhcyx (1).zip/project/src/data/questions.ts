import { Question } from '../types';

export const interviewQuestions: Question[] = [
  {
    id: '1',
    text: 'Tell me about yourself.',
    category: 'general',
    difficulty: 'beginner',
    tips: [
      'Keep it professional and relevant to the role',
      'Structure your answer: present, past, future',
      'Highlight key achievements and skills',
      'Keep it concise (2-3 minutes max)'
    ],
    starMethod: false
  },
  {
    id: '2',
    text: 'Describe a time when you faced a significant challenge at work and how you handled it.',
    category: 'behavioral',
    difficulty: 'intermediate',
    tips: [
      'Use the STAR method (Situation, Task, Action, Result)',
      'Choose a real, specific example',
      'Focus on your actions and decision-making process',
      'Quantify the results if possible'
    ],
    starMethod: true
  },
  {
    id: '3',
    text: 'Where do you see yourself in 5 years?',
    category: 'general',
    difficulty: 'beginner',
    tips: [
      'Show ambition but be realistic',
      'Align your goals with the company\'s growth',
      'Demonstrate commitment to professional development',
      'Avoid mentioning specific job titles unless relevant'
    ],
    starMethod: false
  },
  {
    id: '4',
    text: 'Tell me about a time when you had to lead a team through a difficult situation.',
    category: 'leadership',
    difficulty: 'advanced',
    tips: [
      'Demonstrate leadership skills and emotional intelligence',
      'Show how you motivated and supported your team',
      'Explain your decision-making process',
      'Highlight the positive outcome and lessons learned'
    ],
    starMethod: true
  },
  {
    id: '5',
    text: 'Describe a situation where you had to work with a difficult colleague.',
    category: 'behavioral',
    difficulty: 'intermediate',
    tips: [
      'Focus on your professionalism and conflict resolution skills',
      'Avoid speaking negatively about the colleague',
      'Show how you found common ground or solutions',
      'Demonstrate emotional maturity and teamwork'
    ],
    starMethod: true
  },
  {
    id: '6',
    text: 'What is your greatest weakness?',
    category: 'general',
    difficulty: 'intermediate',
    tips: [
      'Choose a real weakness that won\'t disqualify you',
      'Show self-awareness and growth mindset',
      'Explain steps you\'re taking to improve',
      'Turn it into a learning opportunity'
    ],
    starMethod: false
  },
  {
    id: '7',
    text: 'Describe a time when you had to learn a new skill quickly.',
    category: 'situational',
    difficulty: 'intermediate',
    tips: [
      'Show your adaptability and learning ability',
      'Explain your learning process and resources used',
      'Demonstrate how you applied the new skill',
      'Highlight the successful outcome'
    ],
    starMethod: true
  },
  {
    id: '8',
    text: 'Why are you interested in this position?',
    category: 'general',
    difficulty: 'beginner',
    tips: [
      'Research the company and role thoroughly',
      'Connect your skills and experience to the job requirements',
      'Show genuine enthusiasm for the opportunity',
      'Mention specific aspects of the company culture or mission'
    ],
    starMethod: false
  }
];