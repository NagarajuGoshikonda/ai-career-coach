import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { 
  Target, 
  TrendingUp, 
  Zap, 
  Award, 
  Clock, 
  Brain,
  Rocket,
  Star,
  ChevronRight,
  Play
} from 'lucide-react';
import FuturisticLayout from '../components/Layout/FuturisticLayout';
import GlassPanel from '../components/UI/GlassPanel';
import Avatar3D from '../components/UI/Avatar3D';
import confetti from 'canvas-confetti';

const FuturisticDashboard = () => {
  const { user } = useAuth();
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);

  const stats = [
    {
      id: 'score',
      title: 'Neural Score',
      value: '87',
      change: '+15%',
      icon: Brain,
      color: 'from-blue-500 to-cyan-500',
      description: 'AI-calculated performance index'
    },
    {
      id: 'sessions',
      title: 'Practice Sessions',
      value: '42',
      change: '+12',
      icon: Target,
      color: 'from-purple-500 to-pink-500',
      description: 'Completed this month'
    },
    {
      id: 'time',
      title: 'Focus Time',
      value: '18h',
      change: '+5h',
      icon: Clock,
      color: 'from-green-500 to-emerald-500',
      description: 'Deep practice hours'
    },
    {
      id: 'improvement',
      title: 'Skill Velocity',
      value: '23%',
      change: '+8%',
      icon: TrendingUp,
      color: 'from-orange-500 to-red-500',
      description: 'Learning acceleration rate'
    }
  ];

  const achievements = [
    { title: 'First Interview Ace', icon: '🎯', unlocked: true },
    { title: 'Confidence Booster', icon: '💪', unlocked: true },
    { title: 'STAR Method Master', icon: '⭐', unlocked: true },
    { title: 'Neural Network', icon: '🧠', unlocked: false },
    { title: 'Interview Ninja', icon: '🥷', unlocked: false },
    { title: 'Career Catalyst', icon: '🚀', unlocked: false }
  ];

  const recentSessions = [
    {
      id: 1,
      question: 'Tell me about yourself',
      score: 92,
      improvement: '+8',
      timestamp: '2 hours ago',
      type: 'behavioral'
    },
    {
      id: 2,
      question: 'Describe a challenging project',
      score: 85,
      improvement: '+12',
      timestamp: '1 day ago',
      type: 'technical'
    },
    {
      id: 3,
      question: 'Leadership experience',
      score: 78,
      improvement: '+5',
      timestamp: '2 days ago',
      type: 'leadership'
    }
  ];

  const handleCelebration = () => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <FuturisticLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <GlassPanel className="p-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <Avatar3D size="lg" />
                <div>
                  <motion.h1 
                    className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    Welcome back, {user?.fullName}! 🚀
                  </motion.h1>
                  <p className="text-gray-300 mt-2">
                    Your AI-powered interview preparation is accelerating
                  </p>
                  <div className="flex items-center space-x-4 mt-3">
                    <div className="flex items-center space-x-1 text-green-400">
                      <Zap className="h-4 w-4" />
                      <span className="text-sm">Neural mode active</span>
                    </div>
                    <div className="flex items-center space-x-1 text-blue-400">
                      <Star className="h-4 w-4" />
                      <span className="text-sm">Level 7 Practitioner</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleCelebration}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-all shadow-lg flex items-center space-x-2"
              >
                <Play className="h-5 w-5" />
                <span>Start Practice</span>
              </motion.button>
            </div>
          </GlassPanel>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedMetric(stat.id)}
              className="cursor-pointer"
            >
              <GlassPanel className="p-6 h-full">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${stat.color} bg-opacity-20`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-green-400">{stat.change}</div>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">{stat.title}</h3>
                  <p className="text-sm text-gray-400">{stat.description}</p>
                </div>
              </GlassPanel>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Sessions */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <GlassPanel className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold text-white">Recent Sessions</h3>
                  <button className="text-blue-400 hover:text-blue-300 text-sm font-medium flex items-center space-x-1">
                    <span>View All</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                <div className="space-y-4">
                  {recentSessions.map((session, index) => (
                    <motion.div
                      key={session.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      whileHover={{ x: 5 }}
                      className="p-4 bg-white/5 rounded-lg border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="text-white font-medium mb-1">{session.question}</h4>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className="text-gray-400">{session.timestamp}</span>
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              session.type === 'behavioral' ? 'bg-blue-500/20 text-blue-400' :
                              session.type === 'technical' ? 'bg-green-500/20 text-green-400' :
                              'bg-purple-500/20 text-purple-400'
                            }`}>
                              {session.type}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-white">{session.score}</div>
                          <div className="text-sm text-green-400">{session.improvement}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </GlassPanel>
            </motion.div>
          </div>

          {/* Achievements & Quick Actions */}
          <div className="space-y-6">
            {/* Achievements */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <GlassPanel className="p-6">
                <h3 className="text-xl font-semibold text-white mb-6">Achievements</h3>
                <div className="grid grid-cols-3 gap-3">
                  {achievements.map((achievement, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: 1.05 }}
                      className={`p-3 rounded-lg text-center transition-all ${
                        achievement.unlocked 
                          ? 'bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-400/30' 
                          : 'bg-gray-500/10 border border-gray-600/30'
                      }`}
                    >
                      <div className="text-2xl mb-1">{achievement.icon}</div>
                      <div className={`text-xs ${achievement.unlocked ? 'text-yellow-400' : 'text-gray-500'}`}>
                        {achievement.title}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </GlassPanel>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <GlassPanel className="p-6">
                <h3 className="text-xl font-semibold text-white mb-6">Quick Actions</h3>
                <div className="space-y-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white p-3 rounded-lg font-medium transition-all flex items-center justify-center space-x-2"
                  >
                    <Target className="h-4 w-4" />
                    <span>AI Practice Session</span>
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg font-medium transition-all flex items-center justify-center space-x-2"
                  >
                    <Brain className="h-4 w-4" />
                    <span>Neural Analysis</span>
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg font-medium transition-all flex items-center justify-center space-x-2"
                  >
                    <Rocket className="h-4 w-4" />
                    <span>Career Boost</span>
                  </motion.button>
                </div>
              </GlassPanel>
            </motion.div>

            {/* Progress Ring */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
            >
              <GlassPanel className="p-6 text-center">
                <h3 className="text-lg font-semibold text-white mb-4">Weekly Goal</h3>
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <svg className="w-24 h-24 transform -rotate-90">
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-gray-600"
                    />
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={`${2 * Math.PI * 40}`}
                      strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.73)}`}
                      className="text-blue-400"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-bold text-white">73%</span>
                  </div>
                </div>
                <p className="text-sm text-gray-400">11/15 sessions completed</p>
              </GlassPanel>
            </motion.div>
          </div>
        </div>
      </div>
    </FuturisticLayout>
  );
};

export default FuturisticDashboard;