import React from 'react';
import FuturisticLayout from '../components/Layout/FuturisticLayout';
import DomainSetup from '../components/Setup/DomainSetup';

const DomainSetupPage = () => {
  return (
    <FuturisticLayout>
      <DomainSetup />
    </FuturisticLayout>
  );
};

export default DomainSetupPage;