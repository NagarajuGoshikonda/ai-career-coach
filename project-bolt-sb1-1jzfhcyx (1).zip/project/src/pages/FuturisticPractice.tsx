import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Filter, 
  Search, 
  ArrowLeft, 
  Zap, 
  Brain, 
  Target,
  Star,
  Clock,
  TrendingUp,
  Play,
  Sparkles
} from 'lucide-react';
import FuturisticLayout from '../components/Layout/FuturisticLayout';
import GlassPanel from '../components/UI/GlassPanel';
import AdvancedVideoRecorder from '../components/Recording/AdvancedVideoRecorder';
import { interviewQuestions } from '../data/questions';
import { Question } from '../types';
import toast from 'react-hot-toast';
import confetti from 'canvas-confetti';

const FuturisticPractice = () => {
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [aiMode, setAiMode] = useState<'standard' | 'neural' | 'adaptive'>('neural');
  const navigate = useNavigate();

  const filteredQuestions = interviewQuestions.filter(question => {
    const matchesSearch = question.text.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || question.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'all' || question.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const handleStartPractice = (question: Question) => {
    setSelectedQuestion(question);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 }
    });
    toast.success(`Neural mode activated for: ${question.text.substring(0, 50)}...`);
  };

  const handleAnalysisComplete = (analysis: any, audioUrl?: string) => {
    toast.success('AI analysis completed! 🧠');
    
    if (analysis.overall_score >= 85) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      toast.success('Outstanding performance! 🌟');
    }
    
    console.log('Analysis results:', analysis);
    console.log('Audio feedback URL:', audioUrl);
  };

  const handleBackToQuestions = () => {
    setSelectedQuestion(null);
    toast('Returning to question selection');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'from-green-500 to-emerald-500';
      case 'intermediate': return 'from-yellow-500 to-orange-500';
      case 'advanced': return 'from-red-500 to-pink-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'behavioral': return '🧠';
      case 'technical': return '⚡';
      case 'leadership': return '👑';
      case 'situational': return '🎯';
      default: return '💬';
    }
  };

  if (selectedQuestion) {
    return (
      <FuturisticLayout>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <GlassPanel className="p-4">
              <button
                onClick={handleBackToQuestions}
                className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 font-medium transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Neural Question Bank</span>
              </button>
            </GlassPanel>
          </motion.div>
          
          <AdvancedVideoRecorder
            question={selectedQuestion.text}
            questionId={selectedQuestion.id}
            onAnalysisComplete={handleAnalysisComplete}
          />
        </div>
      </FuturisticLayout>
    );
  }

  return (
    <FuturisticLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <GlassPanel className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
                  Neural Practice Arena
                </h1>
                <p className="text-gray-300">
                  AI-powered interview simulation with real-time feedback and adaptive learning
                </p>
              </div>
              
              {/* AI Mode Selector */}
              <div className="flex items-center space-x-2">
                {['standard', 'neural', 'adaptive'].map((mode) => (
                  <motion.button
                    key={mode}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setAiMode(mode as any)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      aiMode === mode
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                        : 'bg-white/10 text-gray-300 hover:bg-white/20'
                    }`}
                  >
                    {mode === 'neural' && <Brain className="h-4 w-4 inline mr-1" />}
                    {mode === 'adaptive' && <Zap className="h-4 w-4 inline mr-1" />}
                    {mode === 'standard' && <Target className="h-4 w-4 inline mr-1" />}
                    {mode.charAt(0).toUpperCase() + mode.slice(1)}
                  </motion.button>
                ))}
              </div>
            </div>
          </GlassPanel>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <GlassPanel className="p-6">
            <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
              {/* Search */}
              <div className="flex-1">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search neural question database..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-10 pr-3 py-3 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                  />
                </div>
              </div>

              {/* Category filter */}
              <div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="block w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white"
                >
                  <option value="all">All Categories</option>
                  <option value="general">General</option>
                  <option value="behavioral">Behavioral</option>
                  <option value="technical">Technical</option>
                  <option value="leadership">Leadership</option>
                  <option value="situational">Situational</option>
                </select>
              </div>

              {/* Difficulty filter */}
              <div>
                <select
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value)}
                  className="block w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white"
                >
                  <option value="all">All Levels</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>

              <div className="flex items-center text-sm text-gray-300">
                <Filter className="h-4 w-4 mr-1" />
                {filteredQuestions.length} questions
              </div>
            </div>
          </GlassPanel>
        </motion.div>

        {/* Questions grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AnimatePresence>
            {filteredQuestions.map((question, index) => (
              <motion.div
                key={question.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                className="group"
              >
                <GlassPanel className="p-6 h-full cursor-pointer" animate={false}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="text-lg">{getCategoryIcon(question.category)}</span>
                        <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">
                          {question.category}
                        </span>
                        <div className={`px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${getDifficultyColor(question.difficulty)} text-white`}>
                          {question.difficulty}
                        </div>
                        {question.starMethod && (
                          <div className="px-2 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                            STAR
                          </div>
                        )}
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-blue-300 transition-colors">
                        {question.text}
                      </h3>
                    </div>
                  </div>

                  {/* AI Enhancement Indicators */}
                  <div className="flex items-center space-x-4 mb-4 text-xs">
                    <div className="flex items-center space-x-1 text-blue-400">
                      <Brain className="h-3 w-3" />
                      <span>Neural Analysis</span>
                    </div>
                    <div className="flex items-center space-x-1 text-purple-400">
                      <Sparkles className="h-3 w-3" />
                      <span>Real-time Feedback</span>
                    </div>
                    <div className="flex items-center space-x-1 text-green-400">
                      <TrendingUp className="h-3 w-3" />
                      <span>Adaptive Learning</span>
                    </div>
                  </div>

                  {/* Tips preview */}
                  <div className="mb-6">
                    <div className="flex items-center space-x-2 mb-2">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <span className="text-sm font-medium text-gray-300">Neural Tips</span>
                    </div>
                    <ul className="space-y-1">
                      {question.tips.slice(0, 2).map((tip, index) => (
                        <li key={index} className="text-sm text-gray-400 flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-xs text-gray-400">
                      <Clock className="h-3 w-3" />
                      <span>Est. 2-3 min</span>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleStartPractice(question)}
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-lg text-sm font-medium transition-all shadow-lg flex items-center space-x-2"
                    >
                      <Play className="h-4 w-4" />
                      <span>Start Neural Practice</span>
                    </motion.button>
                  </div>
                </GlassPanel>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredQuestions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <GlassPanel className="p-8 max-w-md mx-auto">
              <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-300 text-lg mb-4">
                No questions found in the neural database
              </p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                  setSelectedDifficulty('all');
                }}
                className="text-blue-400 hover:text-blue-300 font-medium"
              >
                Reset neural filters
              </button>
            </GlassPanel>
          </motion.div>
        )}
      </div>
    </FuturisticLayout>
  );
};

export default FuturisticPractice;