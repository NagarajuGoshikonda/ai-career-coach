import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Filter, 
  MapPin, 
  DollarSign, 
  Clock, 
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  TrendingUp,
  Users,
  Building,
  Calendar,
  Star,
  Eye,
  Send,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import FuturisticLayout from '../components/Layout/FuturisticLayout';
import GlassPanel from '../components/UI/GlassPanel';
import JobsHeatmap from '../components/Jobs/JobsHeatmap';
import { jobDataEngine } from '../services/jobDataEngine';
import { JobListing, MarketInsight } from '../types/jobs';
import toast from 'react-hot-toast';

const JobsPortal = () => {
  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<JobListing[]>([]);
  const [marketInsights, setMarketInsights] = useState<MarketInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [salaryFilter, setSalaryFilter] = useState('');
  const [remoteFilter, setRemoteFilter] = useState('all');
  const [experienceFilter, setExperienceFilter] = useState('all');
  const [savedJobs, setSavedJobs] = useState<Set<string>>(new Set());
  const [appliedJobs, setAppliedJobs] = useState<Set<string>>(new Set());
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [newJobsCount, setNewJobsCount] = useState(0);
  const [lastVisit, setLastVisit] = useState<Date>(new Date());

  useEffect(() => {
    loadInitialData();
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      checkForNewJobs();
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    filterJobs();
  }, [jobs, searchQuery, locationFilter, salaryFilter, remoteFilter, experienceFilter]);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [jobsData, insightsData] = await Promise.all([
        jobDataEngine.searchJobs({ limit: 50 }),
        jobDataEngine.getMarketInsights()
      ]);
      
      setJobs(jobsData);
      setMarketInsights(insightsData);
      
      // Simulate new jobs since last visit
      const newCount = Math.floor(Math.random() * 15) + 5;
      setNewJobsCount(newCount);
      
      toast.success(`${newCount} new jobs since your last visit!`);
    } catch (error) {
      console.error('Failed to load job data:', error);
      toast.error('Failed to load job data');
    } finally {
      setLoading(false);
    }
  };

  const checkForNewJobs = async () => {
    try {
      const newJobs = await jobDataEngine.searchJobs({ limit: 5 });
      const currentJobIds = new Set(jobs.map(job => job.id));
      const actualNewJobs = newJobs.filter(job => !currentJobIds.has(job.id));
      
      if (actualNewJobs.length > 0) {
        setJobs(prev => [...actualNewJobs, ...prev]);
        setNewJobsCount(prev => prev + actualNewJobs.length);
        toast(`${actualNewJobs.length} new jobs posted!`, {
          icon: '🔥',
          duration: 3000
        });
      }
    } catch (error) {
      console.error('Failed to check for new jobs:', error);
    }
  };

  const filterJobs = () => {
    let filtered = [...jobs];

    if (searchQuery) {
      filtered = filtered.filter(job =>
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (locationFilter) {
      filtered = filtered.filter(job =>
        job.location.toLowerCase().includes(locationFilter.toLowerCase())
      );
    }

    if (salaryFilter) {
      const minSalary = parseInt(salaryFilter);
      filtered = filtered.filter(job =>
        job.salary.min && job.salary.min >= minSalary
      );
    }

    if (remoteFilter !== 'all') {
      if (remoteFilter === 'remote') {
        filtered = filtered.filter(job => job.remote);
      } else if (remoteFilter === 'hybrid') {
        filtered = filtered.filter(job => job.hybrid);
      } else if (remoteFilter === 'onsite') {
        filtered = filtered.filter(job => !job.remote && !job.hybrid);
      }
    }

    if (experienceFilter !== 'all') {
      filtered = filtered.filter(job => job.experienceLevel === experienceFilter);
    }

    setFilteredJobs(filtered);
  };

  const handleSaveJob = (jobId: string) => {
    setSavedJobs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(jobId)) {
        newSet.delete(jobId);
        toast('Job removed from saved');
      } else {
        newSet.add(jobId);
        toast.success('Job saved!');
      }
      return newSet;
    });
  };

  const handleApplyJob = (job: JobListing) => {
    setAppliedJobs(prev => new Set([...prev, job.id]));
    toast.success(`Applied to ${job.title} at ${job.company}!`);
    
    // Open job application in new tab
    window.open(job.sourceUrl, '_blank');
  };

  const getApplicationStatus = (job: JobListing) => {
    if (appliedJobs.has(job.id)) return 'applied';
    return job.applicationStatus || 'not-applied';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied': return 'bg-blue-500/20 text-blue-400 border-blue-400/30';
      case 'interviewed': return 'bg-purple-500/20 text-purple-400 border-purple-400/30';
      case 'offered': return 'bg-green-500/20 text-green-400 border-green-400/30';
      case 'rejected': return 'bg-red-500/20 text-red-400 border-red-400/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-400/30';
    }
  };

  const getMatchScoreColor = (score?: number) => {
    if (!score) return 'text-gray-400';
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (loading) {
    return (
      <FuturisticLayout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-white/20 rounded w-1/3"></div>
            <div className="h-64 bg-white/20 rounded"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-32 bg-white/20 rounded"></div>
                ))}
              </div>
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-24 bg-white/20 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </FuturisticLayout>
    );
  }

  return (
    <FuturisticLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header with live updates */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <GlassPanel className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
                  AI Career Nexus
                </h1>
                <p className="text-gray-300">
                  Real-time job opportunities powered by AI insights
                </p>
              </div>
              
              {newJobsCount > 0 && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 rounded-full text-sm font-medium"
                >
                  🔥 {newJobsCount} new jobs since your last visit
                </motion.div>
              )}
            </div>
          </GlassPanel>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <GlassPanel className="p-6">
            <div className="space-y-4">
              {/* Main search */}
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search jobs, companies, or skills..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="block w-full pl-10 pr-3 py-3 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                  />
                </div>
                
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Location"
                    value={locationFilter}
                    onChange={(e) => setLocationFilter(e.target.value)}
                    className="block w-full pl-10 pr-3 py-3 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                  />
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center space-x-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
                >
                  <Filter className="h-5 w-5" />
                  <span>Filters</span>
                </motion.button>
              </div>

              {/* Advanced filters */}
              <AnimatePresence>
                {showFilters && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/10"
                  >
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Minimum Salary
                      </label>
                      <select
                        value={salaryFilter}
                        onChange={(e) => setSalaryFilter(e.target.value)}
                        className="block w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white"
                      >
                        <option value="">Any</option>
                        <option value="50000">$50,000+</option>
                        <option value="75000">$75,000+</option>
                        <option value="100000">$100,000+</option>
                        <option value="150000">$150,000+</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Work Type
                      </label>
                      <select
                        value={remoteFilter}
                        onChange={(e) => setRemoteFilter(e.target.value)}
                        className="block w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white"
                      >
                        <option value="all">All</option>
                        <option value="remote">Remote</option>
                        <option value="hybrid">Hybrid</option>
                        <option value="onsite">On-site</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Experience Level
                      </label>
                      <select
                        value={experienceFilter}
                        onChange={(e) => setExperienceFilter(e.target.value)}
                        className="block w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white"
                      >
                        <option value="all">All Levels</option>
                        <option value="entry">Entry Level</option>
                        <option value="mid">Mid Level</option>
                        <option value="senior">Senior Level</option>
                        <option value="executive">Executive</option>
                      </select>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </GlassPanel>
        </motion.div>

        {/* Jobs Heatmap */}
        <JobsHeatmap className="mb-8" />

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Job Listings */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <GlassPanel className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold text-white">
                    Job Opportunities ({filteredJobs.length})
                  </h3>
                  <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span>Live updates</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {filteredJobs.map((job, index) => (
                    <motion.div
                      key={job.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      whileHover={{ scale: 1.01 }}
                      className="bg-white/5 p-6 rounded-lg border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                      onClick={() => setSelectedJob(job)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            {job.companyLogo && (
                              <img 
                                src={job.companyLogo} 
                                alt={job.company}
                                className="w-10 h-10 rounded object-cover"
                              />
                            )}
                            <div>
                              <h4 className="font-semibold text-white text-lg">{job.title}</h4>
                              <p className="text-gray-400">{job.company}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-6 text-sm text-gray-300 mb-3">
                            <span className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1" />
                              {job.location}
                            </span>
                            {job.salary.min && (
                              <span className="flex items-center">
                                <DollarSign className="h-4 w-4 mr-1" />
                                ${job.salary.min.toLocaleString()} - ${job.salary.max?.toLocaleString()}
                              </span>
                            )}
                            <span className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {new Date(job.postedDate).toLocaleDateString()}
                            </span>
                          </div>
                          
                          <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                            {job.description}
                          </p>
                          
                          <div className="flex items-center space-x-2 mb-4">
                            {job.remote && (
                              <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                                Remote
                              </span>
                            )}
                            {job.hybrid && (
                              <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full">
                                Hybrid
                              </span>
                            )}
                            {job.trending && (
                              <span className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs rounded-full">
                                🔥 Trending
                              </span>
                            )}
                            {job.verified && (
                              <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded-full">
                                ✓ Verified
                              </span>
                            )}
                            <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(getApplicationStatus(job))}`}>
                              {getApplicationStatus(job).replace('-', ' ').toUpperCase()}
                            </span>
                          </div>
                        </div>
                        
                        <div className="text-right ml-4">
                          {job.matchScore && (
                            <div className="mb-3">
                              <span className="text-xs text-gray-400">Match: </span>
                              <span className={`font-semibold ${getMatchScoreColor(job.matchScore)}`}>
                                {job.matchScore}%
                              </span>
                            </div>
                          )}
                          
                          <div className="flex items-center space-x-2">
                            <motion.button
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSaveJob(job.id);
                              }}
                              className={`p-2 rounded-lg transition-colors ${
                                savedJobs.has(job.id) 
                                  ? 'text-yellow-400 bg-yellow-500/20' 
                                  : 'text-gray-400 hover:text-yellow-400'
                              }`}
                            >
                              {savedJobs.has(job.id) ? 
                                <BookmarkCheck className="h-4 w-4" /> : 
                                <Bookmark className="h-4 w-4" />
                              }
                            </motion.button>
                            
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleApplyJob(job);
                              }}
                              disabled={appliedJobs.has(job.id)}
                              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                                appliedJobs.has(job.id)
                                  ? 'bg-gray-500/20 text-gray-400 cursor-not-allowed'
                                  : 'bg-blue-600 hover:bg-blue-700 text-white'
                              }`}
                            >
                              {appliedJobs.has(job.id) ? (
                                <div className="flex items-center space-x-1">
                                  <CheckCircle className="h-4 w-4" />
                                  <span>Applied</span>
                                </div>
                              ) : (
                                <div className="flex items-center space-x-1">
                                  <Send className="h-4 w-4" />
                                  <span>Apply</span>
                                </div>
                              )}
                            </motion.button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {filteredJobs.length === 0 && (
                  <div className="text-center py-12">
                    <AlertCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-300 text-lg mb-4">
                      No jobs found matching your criteria
                    </p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setLocationFilter('');
                        setSalaryFilter('');
                        setRemoteFilter('all');
                        setExperienceFilter('all');
                      }}
                      className="text-blue-400 hover:text-blue-300 font-medium"
                    >
                      Clear all filters
                    </button>
                  </div>
                )}
              </GlassPanel>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Market Insights */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <GlassPanel className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Market Insights
                </h3>
                
                <div className="space-y-4">
                  {marketInsights.slice(0, 3).map((insight, index) => (
                    <motion.div
                      key={insight.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      className="p-4 bg-white/5 rounded-lg border border-white/10"
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${
                          insight.impact === 'high' ? 'bg-red-500/20 text-red-400' :
                          insight.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-green-500/20 text-green-400'
                        }`}>
                          {insight.category === 'hiring' ? <Users className="h-4 w-4" /> :
                           insight.category === 'layoffs' ? <AlertCircle className="h-4 w-4" /> :
                           <Building className="h-4 w-4" />}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-white text-sm mb-1">
                            {insight.title}
                          </h4>
                          <p className="text-gray-400 text-xs mb-2">
                            {insight.summary}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">
                              {new Date(insight.publishedAt).toLocaleDateString()}
                            </span>
                            <a
                              href={insight.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 hover:text-blue-300 text-xs flex items-center"
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              {insight.source}
                            </a>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </GlassPanel>
            </motion.div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <GlassPanel className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Your Activity</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Saved Jobs</span>
                    <span className="text-white font-semibold">{savedJobs.size}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Applications</span>
                    <span className="text-white font-semibold">{appliedJobs.size}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Profile Views</span>
                    <span className="text-white font-semibold">127</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Interview Invites</span>
                    <span className="text-white font-semibold">3</span>
                  </div>
                </div>
              </GlassPanel>
            </motion.div>

            {/* Recommended Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <GlassPanel className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Recommended</h3>
                
                <div className="space-y-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <div>
                        <p className="text-white text-sm font-medium">Update your skills</p>
                        <p className="text-gray-400 text-xs">Add React to increase matches by 23%</p>
                      </div>
                    </div>
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <Eye className="h-4 w-4 text-blue-400" />
                      <div>
                        <p className="text-white text-sm font-medium">Practice interviews</p>
                        <p className="text-gray-400 text-xs">Boost confidence for upcoming interviews</p>
                      </div>
                    </div>
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <Calendar className="h-4 w-4 text-green-400" />
                      <div>
                        <p className="text-white text-sm font-medium">Schedule networking</p>
                        <p className="text-gray-400 text-xs">Connect with 3 professionals this week</p>
                      </div>
                    </div>
                  </motion.button>
                </div>
              </GlassPanel>
            </motion.div>
          </div>
        </div>
      </div>
    </FuturisticLayout>
  );
};

export default JobsPortal;