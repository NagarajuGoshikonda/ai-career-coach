import React from 'react';
import Layout from '../components/Layout/Layout';
import ProgressChart from '../components/Dashboard/ProgressChart';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Target, Clock, Award, CheckCircle, AlertCircle } from 'lucide-react';

const Progress = () => {
  const skillsData = [
    { skill: 'Communication', score: 85, target: 90 },
    { skill: 'Body Language', score: 72, target: 80 },
    { skill: 'Content Structure', score: 78, target: 85 },
    { skill: 'Confidence', score: 81, target: 90 },
    { skill: 'Technical Knowledge', score: 65, target: 75 }
  ];

  const categoryData = [
    { name: 'Behavioral', value: 45, color: '#3B82F6' },
    { name: 'Technical', value: 25, color: '#14B8A6' },
    { name: 'Leadership', value: 20, color: '#F97316' },
    { name: 'General', value: 10, color: '#8B5CF6' }
  ];

  const strengths = [
    'Clear articulation and speech pace',
    'Strong technical knowledge demonstration',
    'Good use of specific examples',
    'Professional demeanor and confidence'
  ];

  const improvements = [
    'Reduce filler words (currently 8 per minute)',
    'Improve eye contact consistency',
    'Better STAR method structure',
    'More concise responses'
  ];

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Your Progress
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Track your interview skills improvement over time
          </p>
        </div>

        {/* Key metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Overall Score</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">78/100</p>
                <p className="text-sm text-success-600 dark:text-success-400">+12% this month</p>
              </div>
              <Award className="h-8 w-8 text-primary-600 dark:text-primary-400" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sessions</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">24</p>
                <p className="text-sm text-success-600 dark:text-success-400">+8 this week</p>
              </div>
              <Target className="h-8 w-8 text-primary-600 dark:text-primary-400" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Practice Time</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">8.5h</p>
                <p className="text-sm text-success-600 dark:text-success-400">+2.5h this week</p>
              </div>
              <Clock className="h-8 w-8 text-primary-600 dark:text-primary-400" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Improvement</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">15%</p>
                <p className="text-sm text-success-600 dark:text-success-400">Above average</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary-600 dark:text-primary-400" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Skills breakdown */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Skills Breakdown</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={skillsData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis 
                    dataKey="skill" 
                    axisLine={false}
                    tickLine={false}
                    className="text-gray-600 dark:text-gray-400"
                    angle={-45}
                    textAnchor="end"
                    height={100}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'var(--tooltip-bg)',
                      border: '1px solid var(--tooltip-border)',
                      borderRadius: '8px',
                      color: 'var(--tooltip-text)'
                    }}
                  />
                  <Bar dataKey="score" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="target" fill="#E5E7EB" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Practice distribution */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Practice Distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              {categoryData.map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {item.name} ({item.value}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Progress over time */}
        <div className="mb-8">
          <ProgressChart />
        </div>

        {/* Strengths and improvements */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Strengths */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-2 mb-6">
              <CheckCircle className="h-5 w-5 text-success-600 dark:text-success-400" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Your Strengths</h3>
            </div>
            <div className="space-y-4">
              {strengths.map((strength, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="bg-success-100 dark:bg-success-900/30 p-1 rounded-full mt-0.5">
                    <CheckCircle className="h-3 w-3 text-success-600 dark:text-success-400" />
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{strength}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Areas for improvement */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-2 mb-6">
              <AlertCircle className="h-5 w-5 text-warning-600 dark:text-warning-400" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Areas for Improvement</h3>
            </div>
            <div className="space-y-4">
              {improvements.map((improvement, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="bg-warning-100 dark:bg-warning-900/30 p-1 rounded-full mt-0.5">
                    <AlertCircle className="h-3 w-3 text-warning-600 dark:text-warning-400" />
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{improvement}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Progress;