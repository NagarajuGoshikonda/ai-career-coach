import React from 'react';
import Layout from '../components/Layout/Layout';
import DashboardStats from '../components/Dashboard/DashboardStats';
import RecentSessions from '../components/Dashboard/RecentSessions';
import ProgressChart from '../components/Dashboard/ProgressChart';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Target, TrendingUp } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Welcome back, {user?.fullName}!
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Here's your interview preparation progress
          </p>
        </div>

        {/* Stats grid */}
        <div className="mb-8">
          <DashboardStats />
        </div>

        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent sessions - takes up 2 columns */}
          <div className="lg:col-span-2">
            <RecentSessions />
          </div>

          {/* Quick actions */}
          <div className="space-y-6">
            {/* Quick practice */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                <button className="w-full bg-primary-600 hover:bg-primary-700 text-white p-3 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2">
                  <Target className="h-4 w-4" />
                  <span>Start Practice Session</span>
                </button>
                <button className="w-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-900 dark:text-white p-3 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2">
                  <Calendar className="h-4 w-4" />
                  <span>Schedule Practice</span>
                </button>
                <button className="w-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-900 dark:text-white p-3 rounded-lg text-sm font-medium transition-colors flex items-center justify-center space-x-2">
                  <TrendingUp className="h-4 w-4" />
                  <span>View Progress</span>
                </button>
              </div>
            </div>

            {/* Next goal */}
            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-6 border border-primary-200 dark:border-primary-800">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Your Next Goal
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                Complete 5 more practice sessions to unlock advanced feedback features
              </p>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600 dark:text-gray-400">Progress</span>
                  <span className="text-gray-900 dark:text-white font-medium">3/5</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-primary-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Progress chart */}
        <div className="mt-8">
          <ProgressChart />
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;