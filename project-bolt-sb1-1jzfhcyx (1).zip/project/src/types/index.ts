export interface User {
  id: string;
  email: string;
  fullName: string;
  avatar?: string;
  createdAt: string;
  subscription: 'free' | 'pro' | 'enterprise';
}

export interface InterviewSession {
  id: string;
  userId: string;
  questionId: string;
  videoUrl?: string;
  audioUrl?: string;
  duration: number;
  createdAt: string;
  analysis?: AnalysisResult;
  score?: number;
}

export interface Question {
  id: string;
  text: string;
  category: 'behavioral' | 'technical' | 'situational' | 'leadership' | 'general';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tips: string[];
  starMethod: boolean;
}

export interface AnalysisResult {
  speechAnalysis: {
    fillerWords: number;
    pace: number; // words per minute
    clarity: number; // 0-100
    volume: number; // 0-100
  };
  bodyLanguage: {
    eyeContact: number; // 0-100
    posture: number; // 0-100
    gestures: number; // 0-100
    confidence: number; // 0-100
  };
  contentAnalysis: {
    structure: number; // 0-100
    starCompliance: number; // 0-100 if applicable
    relevance: number; // 0-100
    completeness: number; // 0-100
  };
  overallScore: number; // 0-100
  recommendations: string[];
  strengths: string[];
  weaknesses: string[];
}

export interface ProgressData {
  totalSessions: number;
  averageScore: number;
  improvementRate: number;
  strongestAreas: string[];
  weakestAreas: string[];
  monthlyProgress: {
    month: string;
    score: number;
    sessions: number;
  }[];
}

export interface VoiceFeedback {
  id: string;
  sessionId: string;
  audioUrl: string;
  transcript: string;
  createdAt: string;
}