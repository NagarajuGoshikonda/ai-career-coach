export interface JobListing {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  location: string;
  remote: boolean;
  hybrid: boolean;
  salary: {
    min?: number;
    max?: number;
    currency: string;
    period: 'hourly' | 'monthly' | 'yearly';
  };
  description: string;
  requirements: string[];
  benefits: string[];
  postedDate: string;
  expiryDate?: string;
  source: 'linkedin' | 'indeed' | 'glassdoor' | 'company' | 'government';
  sourceUrl: string;
  applicationCount?: number;
  viewCount?: number;
  trending: boolean;
  verified: boolean;
  tags: string[];
  skillsRequired: string[];
  experienceLevel: 'entry' | 'mid' | 'senior' | 'executive';
  department: string;
  employmentType: 'full-time' | 'part-time' | 'contract' | 'internship';
  applicationStatus?: 'not-applied' | 'applied' | 'interviewed' | 'rejected' | 'offered';
  matchScore?: number; // AI-calculated match percentage
}

export interface TrendingSkill {
  name: string;
  demand: number; // percentage increase
  averageSalary: number;
  jobCount: number;
  growth: 'rising' | 'stable' | 'declining';
  category: string;
}

export interface MarketInsight {
  id: string;
  title: string;
  summary: string;
  impact: 'high' | 'medium' | 'low';
  category: 'hiring' | 'layoffs' | 'merger' | 'funding' | 'policy';
  companies: string[];
  affectedRoles: string[];
  publishedAt: string;
  source: string;
  sourceUrl: string;
}

export interface SalaryPrediction {
  role: string;
  location: string;
  experience: number;
  predicted: {
    min: number;
    max: number;
    median: number;
    confidence: number;
  };
  factors: {
    name: string;
    impact: number;
    description: string;
  }[];
  marketData: {
    totalJobs: number;
    averagePosted: number;
    competitionLevel: 'low' | 'medium' | 'high';
  };
}

export interface SkillGapAnalysis {
  userSkills: string[];
  targetRole: string;
  missingSkills: {
    skill: string;
    importance: number;
    timeToLearn: string;
    resources: {
      name: string;
      type: 'course' | 'certification' | 'book' | 'practice';
      url: string;
      cost: number;
      duration: string;
    }[];
  }[];
  strengthSkills: string[];
  improvementAreas: string[];
  overallReadiness: number;
}